<?php

declare(strict_types=1);

require_once __DIR__ . '/schema.php';

/**
 * CENTRAL ROUTER
 */
$requestPath = seo_request_path();
$requestPath = ltrim($requestPath, '/');

// 1. Static Routes
if ($requestPath === '') {
    // Show homepage - let the script continue
} elseif ($requestPath === 'dmca') {
    require __DIR__ . '/dmca.php'; exit;
} elseif ($requestPath === 'contact') {
    require __DIR__ . '/contact.php'; exit;
} elseif ($requestPath === 'privacy-policy') {
    require __DIR__ . '/privacy-policy.php'; exit;
} elseif ($requestPath === 'copyright') {
    require __DIR__ . '/copyright.php'; exit;
} elseif ($requestPath === 'blocked') {
    require __DIR__ . '/blocked.php'; exit;
} elseif ($requestPath === 'sitemap.xml') {
    require __DIR__ . '/sitemap.php'; exit;
} elseif (preg_match('#^sitemap-(\d+)\.xml$#', $requestPath, $m)) {
    $_GET['page'] = $m[1];
    require __DIR__ . '/sitemap_page.php'; exit;
} elseif ($requestPath === 'authors') {
    header('Location: /', true, 301); exit;
} elseif (preg_match('#^authors/([^/]+)$#', $requestPath, $m)) {
    $_GET['slug'] = $m[1];
    require __DIR__ . '/authors.php'; exit;
} else {
    // 2. Dynamic Slugs (AGC Content)
    $allSlugs = db_get_all_slugs();
    $hostSlug = db_get_host_slug();
    
    foreach ($allSlugs as $s) {
        $s = urlencode($s); // Ensure we match encoded slugs if they exist
        $prefix = $s . '/';
        if (strpos($requestPath, $prefix) === 0) {
            $keyword = substr($requestPath, strlen($prefix));
            if ($keyword !== '') {
                // If the slug used isn't the preferred one for this host, redirect (301)
                // This ensures each host has its own unique primary URL structure
                if ($s !== $hostSlug) {
                    header('Location: /' . $hostSlug . '/' . $keyword, true, 301);
                    exit;
                }
                $_GET['q'] = rawurldecode($keyword);
                require __DIR__ . '/agc_clean.php';
                exit;
            }
        }
    }
    
    // 3. Fallback
    header('Location: /', true, 302);
    exit;
}

/**
 * HOMEPAGE LOGIC
 */

function svg_thumb_data_uri(string $seed, int $w, int $h): string
{
    $seed = trim($seed);
    $hash = substr(sha1($seed), 0, 12);
    $c1 = substr($hash, 0, 6);
    $c2 = substr($hash, 6, 6);
    $label = strtoupper(substr(preg_replace('/\s+/', ' ', $seed) ?? '', 0, 26));

    $fontSize = (int) max(12, min(64, (int) floor($w / 12)));
    if ($w <= 220) {
        $fontSize = (int) max(12, min(18, (int) floor($w / 11)));
    }

    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' . $w . '" height="' . $h . '" viewBox="0 0 ' . $w . ' ' . $h . '">' .
        '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' .
        '<stop offset="0" stop-color="#' . $c1 . '"/>' .
        '<stop offset="1" stop-color="#' . $c2 . '"/>' .
        '</linearGradient></defs>' .
        '<rect width="100%" height="100%" fill="url(#g)"/>' .
        '<rect x="0" y="0" width="100%" height="100%" fill="rgba(0,0,0,0.22)"/>' .
        '<text x="18" y="' . (int) ($h * 0.56) . '" fill="#fff" font-family="system-ui,-apple-system,Segoe UI,Roboto,Arial" font-size="' . $fontSize . '" font-weight="900">' . htmlspecialchars($label, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</text>' .
        '</svg>';

    return 'data:image/svg+xml;utf8,' . rawurlencode($svg);
}





function latest_pick_bing_image(string $keyword): string
{
    $tries = [
        $keyword,
        $keyword . ' photo',
        $keyword . ' wallpaper',
    ];

    foreach ($tries as $q) {
        $fetch = bing_image_search_cached($q, 1);
        if (($fetch['ok'] ?? false) && isset($fetch['images'][0])) {
            $img = trim((string) $fetch['images'][0]);
            if ($img !== '') {
                return img_cache_bing_url($img);
            }
        }
    }

    $fetch = bing_image_search_cached($keyword, 8);
    if (($fetch['ok'] ?? false) && isset($fetch['images']) && is_array($fetch['images'])) {
        foreach ($fetch['images'] as $u) {
            $u = trim((string) $u);
            if ($u !== '') {
                return img_cache_bing_url($u);
            }
        }
    }

    return svg_thumb_data_uri($keyword . ' latest', 560, 360);
}

$scheme = seo_detect_scheme();
$host = seo_detect_host();
$base = $scheme . '://' . $host;
$canonical = $base . '/';

// LOAD CONFIG FROM DB
$siteName = db_get_config('site_name', 'AGC James');
$pageTitle = db_get_config('index_title', $siteName);
$metaDescription = db_get_config('meta_description', 'Latest updates and trending stories.');
$currentSlug = db_get_host_slug();

$keywords = db_get_keywords(2000);
if (count($keywords) === 0) {
    $rawFallbacks = ['featured article', 'latest trends', 'top stories', 'editorial pick'];
    foreach ($rawFallbacks as $f) {
        $keywords[] = ['slug' => slugify($f), 'title' => ucwords($f)];
    }
}

$contentScript = is_file(__DIR__ . '/agc_clean.php') ? 'agc_clean.php' : 'agc.php';

function content_href(string $slug, string $q): string
{
    $q = trim($q);
    return '/' . $slug . '/' . rawurlencode($q);
}

$categories = array_slice($keywords, 0, 4);
while (count($categories) < 4) {
    $catNum = count($categories) + 1;
    $fallbackLabel = 'category ' . str_pad((string) $catNum, 4, '0', STR_PAD_LEFT);
    $categories[] = ['slug' => slugify($fallbackLabel), 'title' => ucwords($fallbackLabel)];
}

// LOAD AUTHORS
$authorsJson = __DIR__ . '/authors.json';
$authorsPool = [];
if (is_file($authorsJson)) {
    $raw = file_get_contents($authorsJson);
    $authorsPool = json_decode($raw, true) ?: [];
}

function get_random_author(array $pool, string $defaultName): array
{
    if (count($pool) > 0) {
        return $pool[array_rand($pool)];
    }
    return ['name' => $defaultName, 'slug' => ''];
}

$featuredKw = $keywords[0];
$featuredFetch = bing_image_search_cached($featuredKw['slug'], 6);
if (($featuredFetch['ok'] ?? false) && isset($featuredFetch['images']) && is_array($featuredFetch['images'])) {
    $featuredImages = array_values(array_filter(array_map(function ($u) {
        $u = trim((string) $u);
        return $u !== '' ? img_cache_bing_url($u) : null;
    }, $featuredFetch['images'])));
}
while (count($featuredImages) < 3) {
    $suffix = ['A', 'B', 'C'][count($featuredImages)] ?? 'X';
    $featuredImages[] = svg_thumb_data_uri($featuredKw['title'] . ' ' . $suffix, 720, 430);
}

$featAuthor = get_random_author($authorsPool, $siteName);
$featured = [
    'category' => $categories[0]['title'],
    'title' => $featuredKw['title'],
    'author' => $featAuthor['name'],
    'authorSlug' => $featAuthor['slug'],
    'date' => gmdate('M d, Y'),
    'q' => $featuredKw['slug'],
    'images' => [
        $featuredImages[0],
        $featuredImages[1],
        $featuredImages[2],
    ],
];

$popular = [];
foreach (array_slice($keywords, 1, 3) as $idx => $kw) {
    $img = '';
    $fetch = bing_image_search_cached($kw['slug'], 1);
    if (($fetch['ok'] ?? false) && isset($fetch['images'][0])) {
        $img = img_cache_bing_url(trim((string) $fetch['images'][0]));
    }
    if ($img === '') {
        $img = svg_thumb_data_uri($kw['title'], 160, 120);
    }
    $popAuthor = get_random_author($authorsPool, $siteName);
    $popular[] = [
        'category' => $categories[min($idx, 3)]['title'],
        'title' => $kw['title'],
        'author' => $popAuthor['name'],
        'authorSlug' => $popAuthor['slug'],
        'date' => gmdate('M d, Y', time() - ($idx + 1) * 86400),
        'q' => $kw['slug'],
        'image' => $img,
    ];
}

$latest = [];
$latestLimit = 5;
$latestSlice = array_slice($keywords, max(0, count($keywords) - $latestLimit));
$latestSlice = array_reverse($latestSlice);
foreach ($latestSlice as $idx => $kw) {
    $img = latest_pick_bing_image($kw['slug']);
    $latAuthor = get_random_author($authorsPool, $siteName);
    $latest[] = [
        'category' => $categories[$idx % 4]['title'],
        'title' => $kw['title'],
        'author' => $latAuthor['name'],
        'authorSlug' => $latAuthor['slug'],
        'date' => gmdate('M d, Y', time() - ($idx) * 86400),
        'q' => $kw['slug'],
        'image' => $img,
    ];
}

$ogImage = $featured['images'][0];

$schema = json_encode([
    '@context' => 'https://schema.org',
    '@graph' => [
        [
            '@type' => 'WebSite',
            '@id' => $canonical . '#website',
            'url' => $canonical,
            'name' => $siteName,
        ],
        [
            '@type' => 'WebPage',
            '@id' => $canonical . '#webpage',
            'url' => $canonical,
            'name' => $siteName,
            'isPartOf' => ['@id' => $canonical . '#website'],
            'description' => $metaDescription,
        ],
        [
            '@type' => 'BreadcrumbList',
            '@id' => $canonical . '#breadcrumb',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Home',
                    'item' => $canonical,
                ],
            ],
        ],
    ],
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

header('Content-Type: text/html; charset=UTF-8');

?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= e($pageTitle) ?></title>
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="shortcut icon" href="/favicon.svg">
  <meta name="description" content="<?= e($metaDescription) ?>">
  <link rel="canonical" href="<?= e($canonical) ?>">
  <meta name="robots" content="index,follow">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="<?= e($siteName) ?>">
  <meta property="og:title" content="<?= e($pageTitle) ?>">
  <meta property="og:description" content="<?= e($metaDescription) ?>">
  <meta property="og:url" content="<?= e($canonical) ?>">
  <meta property="og:image" content="<?= e($ogImage) ?>">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?= e($pageTitle) ?>">
  <meta name="twitter:description" content="<?= e($metaDescription) ?>">
  <meta name="twitter:image" content="<?= e($ogImage) ?>">
  <script type="application/ld+json"><?= $schema !== false ? $schema : '{}' ?></script>
  <style>
    :root{--bg:#0f1218;--bg2:#141a23;--panel:#141b26;--panel2:#101621;--text:#f2f4f7;--muted:#9aa7b6;--muted2:#7b8796;--accent:#ff3b3b;--accent2:#ff3b9a;--border:rgba(255,255,255,.08);--shadow:0 16px 40px rgba(0,0,0,.35)}
    *{box-sizing:border-box}
    body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:linear-gradient(180deg,var(--bg),#0b0e14);color:var(--text);line-height:1.55}
    a{color:inherit;text-decoration:none}
    a:hover{text-decoration:underline}
    .container{max-width:1120px;margin:0 auto;padding:0 22px}
    .topbar{background:#0b0e14;border-bottom:1px solid var(--border)}
    .topbar-inner{display:flex;align-items:center;gap:18px;min-height:58px}
    .brand{display:flex;align-items:center;gap:10px;font-weight:800;letter-spacing:.08em}
    .nav{margin-left:auto;display:flex;align-items:center;gap:18px;flex-wrap:wrap}
    .nav a{color:#e9eef6;font-size:.86rem;opacity:.95}
    .iconbtn{width:34px;height:34px;border:1px solid var(--border);background:rgba(255,255,255,.02);border-radius:10px;display:grid;place-items:center}
    .catstrip{background:linear-gradient(90deg,#d73232,#ff3b3b,#c03ab6);border-bottom:1px solid rgba(255,255,255,.14)}
    .catstrip-inner{display:flex;gap:14px;align-items:center;min-height:44px;overflow:auto;padding:0 2px}
    .chip{display:flex;align-items:center;gap:10px;color:#fff;font-size:.82rem;font-weight:700;white-space:nowrap;padding:10px 12px}
    .main{padding:26px 0 34px}
    .grid{display:grid;grid-template-columns:1.55fr .85fr;gap:24px;align-items:start}
    .section-label{display:flex;align-items:center;gap:8px;font-weight:800;font-size:.8rem;letter-spacing:.12em;color:#e9eef6;opacity:.9}
    .card{background:linear-gradient(180deg,rgba(255,255,255,.03),rgba(255,255,255,.015));border:1px solid var(--border);border-radius:16px;box-shadow:var(--shadow)}
    .featured{padding:16px}
    .ptitle{font-size:1.1rem;font-weight:700;margin:4px 0}
    .pmeta{font-size:.82rem;color:var(--muted);margin-top:4px}
    .latest-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:20px;margin-top:16px}
    .post{display:flex;flex-direction:column;gap:12px}
    .footer{background:#0b0e14;border-top:1px solid var(--border);padding:26px 0;color:var(--muted);font-size:.9rem}
    @media (max-width:880px){.grid{grid-template-columns:1fr}}
  </style>
</head>
<body>
  <div class="topbar">
    <div class="container">
      <div class="topbar-inner">
        <a class="brand" href="/"><span><?= e($siteName) ?></span></a>
        <nav class="nav">
          <a href="/">Home</a>
          <a href="/dmca">DMCA</a>
          <a href="/contact">Contact</a>
          <a href="/privacy-policy">Privacy Policy</a>
          <a href="/copyright">Copyright</a>
        </nav>
      </div>
    </div>
  </div>

  <div class="catstrip">
    <div class="container">
      <div class="catstrip-inner">
        <?php foreach ($categories as $cat): ?>
          <a class="chip" href="<?= e(content_href($currentSlug, (string) $cat['slug'])) ?>"><span class="dot"></span><span class="tag"><?= e($cat['title']) ?></span></a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <main class="main">
    <div class="container">
      <div class="grid">
        <section id="featured">
          <div class="section-label"><span style="color:var(--accent)">/</span> FEATURED POST</div>
          <article class="card featured" style="margin-top:10px">
            <h1 class="title"><a href="<?= e(content_href($currentSlug, (string) $featured['q'])) ?>"><?= e($featured['title']) ?></a></h1>
            <div class="pmeta">By <a href="/authors/<?= e((string)$featured['authorSlug']) ?>"><?= e($featured['author']) ?></a> - <?= e($featured['date']) ?></div>
            <a href="<?= e(content_href($currentSlug, (string) $featured['q'])) ?>"><img src="<?= e($featured['images'][0]) ?>" style="width:100%;border-radius:12px;margin-top:14px"></a>
          </article>
        </section>
        <aside id="popular">
          <div class="section-label">/ POPULAR</div>
          <div style="margin-top:10px">
            <?php foreach ($popular as $p): ?>
              <div class="card" style="margin-bottom:12px;padding:12px;display:flex;gap:12px">
                <img src="<?= e($p['image']) ?>" style="width:80px;height:60px;border-radius:8px;object-fit:cover">
                <div>
                  <div class="ptitle"><a href="<?= e(content_href($currentSlug, (string) $p['q'])) ?>"><?= e($p['title']) ?></a></div>
                  <div class="pmeta">By <a href="/authors/<?= e((string)$p['authorSlug']) ?>"><?= e($p['author']) ?></a></div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </aside>
      </div>

      <section id="latest" style="margin-top:40px">
        <div class="section-label">/ LATEST POSTS</div>
        <div class="latest-grid">
          <?php foreach ($latest as $p): ?>
            <article class="post card" style="padding:14px">
              <a href="<?= e(content_href($currentSlug, (string) $p['q'])) ?>"><img src="<?= e($p['image']) ?>" style="width:100%;border-radius:10px"></a>
              <div class="ptitle"><a href="<?= e(content_href($currentSlug, (string) $p['q'])) ?>"><?= e($p['title']) ?></a></div>
              <div class="pmeta">By <a href="/authors/<?= e((string)$p['authorSlug']) ?>"><?= e($p['author']) ?></a></div>
            </article>
          <?php endforeach; ?>
        </div>
      </section>
    </div>
  </main>

  <footer class="footer">
    <div class="container">© <?= e((string) date('Y')) ?> <?= e($siteName) ?> • <a href="/sitemap.xml">Sitemap</a></div>
  </footer>
</body>
</html>
