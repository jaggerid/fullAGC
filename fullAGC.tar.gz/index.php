<?php

declare(strict_types=1);

require_once __DIR__ . '/schema.php';

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function slugify(string $text): string
{
    $text = trim($text);
    if ($text === '') {
        return '';
    }

    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
        if (is_string($converted) && $converted !== '') {
            $text = $converted;
        }
    }

    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9\s-]/', '', $text) ?? '';
    $text = preg_replace('/[\s-]+/', '-', $text) ?? '';
    $text = trim($text, '-');
    return $text;
}

function load_keywords(string $filePath, int $limit = 60): array
{
    if (!is_file($filePath)) {
        return [];
    }
    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!is_array($lines)) {
        return [];
    }
    $out = [];
    $seen = [];
    foreach ($lines as $line) {
        $line = trim((string) $line);
        if ($line === '') {
            continue;
        }
        $key = strtolower($line);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = $line;
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function svg_thumb_data_uri(string $seed, int $w, int $h): string
{
    $seed = trim($seed);
    $hash = substr(sha1($seed), 0, 12);
    $c1 = substr($hash, 0, 6);
    $c2 = substr($hash, 6, 6);
    $label = strtoupper(substr(preg_replace('/\s+/', ' ', $seed) ?? '', 0, 26));

    $fontSize = (int) max(12, min(64, (int) floor($w / 12)));
    if ($w <= 220) {
        $fontSize = (int) max(12, min(18, (int) floor($w / 11)));
    }

    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' . $w . '" height="' . $h . '" viewBox="0 0 ' . $w . ' ' . $h . '">' .
        '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' .
        '<stop offset="0" stop-color="#' . $c1 . '"/>' .
        '<stop offset="1" stop-color="#' . $c2 . '"/>' .
        '</linearGradient></defs>' .
        '<rect width="100%" height="100%" fill="url(#g)"/>' .
        '<rect x="0" y="0" width="100%" height="100%" fill="rgba(0,0,0,0.22)"/>' .
        '<text x="18" y="' . (int) ($h * 0.56) . '" fill="#fff" font-family="system-ui,-apple-system,Segoe UI,Roboto,Arial" font-size="' . $fontSize . '" font-weight="900">' . htmlspecialchars($label, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</text>' .
        '</svg>';

    return 'data:image/svg+xml;utf8,' . rawurlencode($svg);
}

function random_user_agent(): string
{
    $agents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0',
    ];
    return $agents[array_rand($agents)];
}

function http_get_with_headers(string $url, array $extraHeaders, int $timeoutSeconds = 12): array
{
    $ua = random_user_agent();
    $headers = [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language: en-US,en;q=0.9,id-ID;q=0.8,id;q=0.7',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
        'DNT: 1',
        'Upgrade-Insecure-Requests: 1',
    ];
    foreach ($extraHeaders as $h) {
        $h = trim((string) $h);
        if ($h !== '') {
            $headers[] = $h;
        }
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => $timeoutSeconds,
            CURLOPT_TIMEOUT => $timeoutSeconds,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => $ua,
            CURLOPT_ENCODING => '',
            CURLOPT_HTTPHEADER => $headers,
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($errno !== 0 || $body === false) {
            return [
                'ok' => false,
                'status' => $status,
                'error' => $error !== '' ? $error : ('cURL error #' . $errno),
                'body' => '',
            ];
        }

        return [
            'ok' => $status >= 200 && $status < 300,
            'status' => $status,
            'error' => '',
            'body' => (string) $body,
        ];
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => $timeoutSeconds,
            'header' => implode("\r\n", array_merge([
                'User-Agent: ' . $ua,
            ], $headers)),
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);

    $body = @file_get_contents($url, false, $context);
    $status = 0;
    if (isset($http_response_header) && is_array($http_response_header)) {
        foreach ($http_response_header as $line) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $m)) {
                $status = (int) $m[1];
                break;
            }
        }
    }

    if ($body === false) {
        return [
            'ok' => false,
            'status' => $status,
            'error' => 'Request gagal (file_get_contents).',
            'body' => '',
        ];
    }

    return [
        'ok' => $status >= 200 && $status < 300,
        'status' => $status,
        'error' => '',
        'body' => (string) $body,
    ];
}

function bing_image_search(string $keyword, int $limit = 3): array
{
    $q = rawurlencode($keyword);
    $endpoints = [
        'https://www.bing.com/images/async?q=' . $q . '&first=0&count=35&adlt=off',
        'https://www.bing.com/images/search?q=' . $q . '&first=0&count=35&adlt=off&form=HDRSC2',
    ];

    $images = [];
    $seen = [];
    $lastStatus = 0;
    $lastErr = '';

    foreach ($endpoints as $url) {
        $res = http_get_with_headers($url, [
            'Referer: https://www.bing.com/',
            'Origin: https://www.bing.com',
        ], 14);
        $lastStatus = (int) ($res['status'] ?? 0);
        if (!$res['ok'] || ($res['body'] ?? '') === '') {
            $lastErr = (string) ($res['error'] ?? '');
            continue;
        }

        $html = (string) $res['body'];
        if (stripos($html, 'captcha') !== false || stripos($html, 'blocked') !== false) {
            return [
                'ok' => false,
                'status' => $lastStatus,
                'error' => 'Scraper terblokir atau memerlukan verifikasi (CAPTCHA).',
                'images' => [],
            ];
        }

        if (preg_match_all('/\biusc\b[\s\S]{0,1200}?\bm=(["\'])(.*?)\1/i', $html, $matches)) {
            $raws = $matches[2] ?? [];
            foreach ($raws as $raw) {
                if (count($images) >= $limit) {
                    break;
                }
                $json = html_entity_decode((string) $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $data = json_decode($json, true);
                if (!is_array($data)) {
                    continue;
                }
                $turl = trim((string) ($data['turl'] ?? ''));
                $murl = trim((string) ($data['murl'] ?? ''));
                $pick = '';

                if ($turl !== '' && preg_match('#^https?://#i', $turl) && preg_match('#\b(bing\.com|mm\.bing\.net)\b#i', $turl)) {
                    $pick = $turl;
                } elseif ($murl !== '' && preg_match('#^https?://#i', $murl) && preg_match('#\b(bing\.com|mm\.bing\.net)\b#i', $murl)) {
                    $pick = $murl;
                }

                if ($pick === '' || isset($seen[$pick])) {
                    continue;
                }

                $seen[$pick] = true;
                $images[] = $pick;
            }
        }

        if (count($images) < $limit) {
            if (preg_match_all('/<img[^>]+(?:data-src|src)=(["\'])(.*?)\1/i', $html, $im)) {
                $srcs = $im[2] ?? [];
                foreach ($srcs as $src) {
                    if (count($images) >= $limit) {
                        break;
                    }
                    $src = html_entity_decode((string) $src, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    $src = trim((string) preg_replace('/\s+.*/', '', $src));
                    if ($src === '' || isset($seen[$src])) {
                        continue;
                    }
                    if (stripos($src, 'data:image') === 0) {
                        continue;
                    }
                    if (!preg_match('#^https?://#i', $src)) {
                        continue;
                    }
                    if (!preg_match('#\b(bing\.com|mm\.bing\.net)\b#i', $src)) {
                        continue;
                    }
                    $seen[$src] = true;
                    $images[] = $src;
                }
            }
        }

        if (count($images) >= $limit) {
            break;
        }
    }

    if (count($images) === 0) {
        return [
            'ok' => false,
            'status' => $lastStatus,
            'error' => $lastErr !== '' ? $lastErr : 'Tidak ada gambar yang bisa diambil. Coba keyword lain.',
            'images' => [],
        ];
    }

    return [
        'ok' => true,
        'status' => $lastStatus,
        'error' => '',
        'images' => array_slice($images, 0, $limit),
    ];
}

function bing_image_search_cached(string $keyword, int $limit, int $ttlSeconds = 21600): array
{
    $cacheDir = __DIR__ . '/cache';
    if (!is_dir($cacheDir)) {
        @mkdir($cacheDir, 0775, true);
    }

    $key = sha1('v2|' . strtolower(trim($keyword)) . '|' . $limit);
    $cacheFile = $cacheDir . '/bing_' . $key . '.json';

    if (is_file($cacheFile)) {
        $age = time() - (int) filemtime($cacheFile);
        if ($age >= 0 && $age < $ttlSeconds) {
            $raw = file_get_contents($cacheFile);
            $data = is_string($raw) ? json_decode($raw, true) : null;
            if (is_array($data) && isset($data['images']) && is_array($data['images'])) {
                return [
                    'ok' => (bool) ($data['ok'] ?? false),
                    'status' => (int) ($data['status'] ?? 200),
                    'error' => (string) ($data['error'] ?? ''),
                    'images' => array_slice((array) $data['images'], 0, $limit),
                ];
            }
        }
    }

    $res = bing_image_search($keyword, $limit);
    @file_put_contents($cacheFile, json_encode($res, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    return $res;
}

function img_cache_enabled(): bool
{
    $v = env_get('IMG_CACHE_ENABLED', '1');
    $v = strtolower(trim((string) $v));
    return $v === '1' || $v === 'true' || $v === 'yes' || $v === 'on';
}

function img_cache_ttl(): int
{
    $v = env_get('IMG_CACHE_TTL', '1209600');
    $n = is_numeric($v) ? (int) $v : 1209600;
    return max(60, $n);
}

function img_cache_dir(): string
{
    $v = trim((string) (env_get('IMG_CACHE_DIR', 'img/bing') ?? 'img/bing'));
    return $v !== '' ? $v : 'img/bing';
}

function http_get_binary(string $url, int $timeoutSeconds = 12): array
{
    $ua = random_user_agent();
    $headers = [
        'Accept: image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
        'Accept-Language: en-US,en;q=0.9',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
        'DNT: 1',
    ];

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => $timeoutSeconds,
            CURLOPT_TIMEOUT => $timeoutSeconds,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => $ua,
            CURLOPT_ENCODING => '',
            CURLOPT_HTTPHEADER => $headers,
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $ctype = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);

        if ($errno !== 0 || $body === false) {
            return [
                'ok' => false,
                'status' => $status,
                'content_type' => $ctype,
                'error' => $error !== '' ? $error : ('cURL error #' . $errno),
                'body' => '',
            ];
        }

        return [
            'ok' => $status >= 200 && $status < 300,
            'status' => $status,
            'content_type' => $ctype,
            'error' => '',
            'body' => (string) $body,
        ];
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => $timeoutSeconds,
            'header' => implode("\r\n", array_merge([
                'User-Agent: ' . $ua,
            ], $headers)),
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);

    $body = @file_get_contents($url, false, $context);
    $status = 0;
    $ctype = '';
    if (isset($http_response_header) && is_array($http_response_header)) {
        foreach ($http_response_header as $line) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $m)) {
                $status = (int) $m[1];
            }
            if (stripos($line, 'content-type:') === 0) {
                $ctype = trim(substr($line, strlen('content-type:')));
            }
        }
    }

    if ($body === false) {
        return [
            'ok' => false,
            'status' => $status,
            'content_type' => $ctype,
            'error' => 'Request gagal (file_get_contents).',
            'body' => '',
        ];
    }

    return [
        'ok' => $status >= 200 && $status < 300,
        'status' => $status,
        'content_type' => $ctype,
        'error' => '',
        'body' => (string) $body,
    ];
}

function img_cache_extension_from_content_type(string $contentType, string $url): string
{
    $ct = strtolower(trim(explode(';', $contentType)[0] ?? ''));
    $map = [
        'image/jpeg' => 'jpg',
        'image/jpg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
        'image/avif' => 'avif',
        'image/svg+xml' => 'svg',
    ];
    if (isset($map[$ct])) {
        return $map[$ct];
    }
    $path = parse_url($url, PHP_URL_PATH);
    $ext = is_string($path) ? strtolower(pathinfo($path, PATHINFO_EXTENSION)) : '';
    if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif'], true)) {
        return $ext === 'jpeg' ? 'jpg' : $ext;
    }
    return 'jpg';
}

function img_cache_bing_url(string $remoteUrl): string
{
    $remoteUrl = trim($remoteUrl);
    if ($remoteUrl === '' || !preg_match('#^https?://#i', $remoteUrl)) {
        return $remoteUrl;
    }
    if (!img_cache_enabled()) {
        return $remoteUrl;
    }

    $dirRel = trim(img_cache_dir(), '/\\');
    $dirAbs = rtrim(__DIR__ . '/' . $dirRel, '/\\');
    if (!is_dir($dirAbs)) {
        @mkdir($dirAbs, 0775, true);
    }

    $hash = sha1($remoteUrl);
    $ttl = img_cache_ttl();

    $existing = glob($dirAbs . '/' . $hash . '.*');
    if (is_array($existing) && count($existing) > 0) {
        $path = (string) $existing[0];
        $age = time() - (int) filemtime($path);
        if ($age >= 0 && $age < $ttl) {
            $rel = '/' . $dirRel . '/' . basename($path);
            return str_replace('\\', '/', $rel);
        }
    }

    $res = http_get_binary($remoteUrl, 14);
    if (!($res['ok'] ?? false)) {
        return $remoteUrl;
    }
    $body = (string) ($res['body'] ?? '');
    if ($body === '') {
        return $remoteUrl;
    }
    if (strlen($body) > 4_000_000) {
        return $remoteUrl;
    }

    $ctype = (string) ($res['content_type'] ?? '');
    if ($ctype !== '' && stripos($ctype, 'image/') !== 0) {
        return $remoteUrl;
    }

    $ext = img_cache_extension_from_content_type($ctype, $remoteUrl);
    $fileAbs = $dirAbs . '/' . $hash . '.' . $ext;
    $tmp = $fileAbs . '.tmp';
    @file_put_contents($tmp, $body);
    @rename($tmp, $fileAbs);

    $rel = '/' . $dirRel . '/' . basename($fileAbs);
    return str_replace('\\', '/', $rel);
}

function latest_pick_bing_image(string $keyword): string
{
    $tries = [
        $keyword,
        $keyword . ' photo',
        $keyword . ' wallpaper',
    ];

    foreach ($tries as $q) {
        $fetch = bing_image_search_cached($q, 1);
        if (($fetch['ok'] ?? false) && isset($fetch['images'][0])) {
            $img = trim((string) $fetch['images'][0]);
            if ($img !== '') {
                return img_cache_bing_url($img);
            }
        }
    }

    $fetch = bing_image_search_cached($keyword, 8);
    if (($fetch['ok'] ?? false) && isset($fetch['images']) && is_array($fetch['images'])) {
        foreach ($fetch['images'] as $u) {
            $u = trim((string) $u);
            if ($u !== '') {
                return img_cache_bing_url($u);
            }
        }
    }

    return svg_thumb_data_uri($keyword . ' latest', 560, 360);
}

$scheme = seo_detect_scheme();
$host = seo_detect_host();
$base = $scheme . '://' . $host;
$canonical = $base . '/';

$siteName = env_get('SITE_NAME', $host) ?? $host;
$pageTitle = $siteName;
$metaDescription = 'Neutral homepage with featured, popular, and latest posts.';

$keywords = load_keywords(__DIR__ . '/sitemap_keywords.txt', 2000);
if (count($keywords) === 0) {
    $keywords = [
        'example keyword',
        'latest update',
        'quick summary',
        'top results',
        'highlights',
        'daily review',
        'new guide',
    ];
}

$contentScript = is_file(__DIR__ . '/agc_clean.php') ? 'agc_clean.php' : 'agc.php';

function content_href(string $contentScript, string $q): string
{
    $q = trim($q);
    return '/super-updates/' . rawurlencode($q);
}

$categories = array_slice($keywords, 0, 4);
while (count($categories) < 4) {
    $categories[] = 'category ' . str_pad((string) (count($categories) + 1), 4, '0', STR_PAD_LEFT);
}

$featuredKw = $keywords[0];
$featuredSlug = slugify($featuredKw);
$featuredImages = [];
$featuredFetch = bing_image_search_cached($featuredKw, 6);
if (($featuredFetch['ok'] ?? false) && isset($featuredFetch['images']) && is_array($featuredFetch['images'])) {
    $featuredImages = array_values(array_filter(array_map(function ($u) {
        $u = trim((string) $u);
        return $u !== '' ? img_cache_bing_url($u) : null;
    }, $featuredFetch['images'])));
}
while (count($featuredImages) < 3) {
    $suffix = ['A', 'B', 'C'][count($featuredImages)] ?? 'X';
    $featuredImages[] = svg_thumb_data_uri($featuredKw . ' ' . $suffix, 720, 430);
}

$featured = [
    'category' => $categories[0],
    'title' => ucwords($featuredKw) . ' Update #'. random_int(100, 999),
    'author' => $siteName,
    'date' => gmdate('M d, Y'),
    'q' => $featuredSlug !== '' ? $featuredSlug : rawurlencode($featuredKw),
    'images' => [
        $featuredImages[0],
        $featuredImages[1],
        $featuredImages[2],
    ],
];

$popular = [];
foreach (array_slice($keywords, 1, 3) as $idx => $kw) {
    $slug = slugify($kw);
    $img = '';
    $fetch = bing_image_search_cached($kw, 1);
    if (($fetch['ok'] ?? false) && isset($fetch['images'][0])) {
        $img = img_cache_bing_url(trim((string) $fetch['images'][0]));
    }
    if ($img === '') {
        $img = svg_thumb_data_uri($kw, 160, 120);
    }
    $popular[] = [
        'category' => $categories[min($idx, 3)],
        'title' => ucwords($kw) . ' #'. random_int(100, 999),
        'author' => $siteName,
        'date' => gmdate('M d, Y', time() - ($idx + 1) * 86400),
        'q' => $slug !== '' ? $slug : rawurlencode($kw),
        'image' => $img,
    ];
}

$latest = [];
$latestLimit = 5;
$latestSlice = array_slice($keywords, max(0, count($keywords) - $latestLimit));
$latestSlice = array_reverse($latestSlice);
foreach ($latestSlice as $idx => $kw) {
    $slug = slugify($kw);
    $img = latest_pick_bing_image($kw);
    $latest[] = [
        'category' => $categories[$idx % 4],
        'title' => ucwords($kw),
        'author' => $siteName,
        'date' => gmdate('M d, Y', time() - ($idx) * 86400),
        'q' => $slug !== '' ? $slug : rawurlencode($kw),
        'image' => $img,
    ];
}
while (count($latest) < $latestLimit) {
    $kw = $keywords[min(count($keywords) - 1, count($latest))] ?? ('post ' . (count($latest) + 1));
    $slug = slugify($kw);
    $img = latest_pick_bing_image($kw);
    $latest[] = [
        'category' => $categories[count($latest) % 4],
        'title' => ucwords($kw),
        'author' => $siteName,
        'date' => gmdate('M d, Y'),
        'q' => $slug !== '' ? $slug : rawurlencode($kw),
        'image' => $img,
    ];
}


$ogImage = $featured['images'][0];

$schema = json_encode([
    '@context' => 'https://schema.org',
    '@graph' => [
        [
            '@type' => 'WebSite',
            '@id' => $canonical . '#website',
            'url' => $canonical,
            'name' => $siteName,
        ],
        [
            '@type' => 'WebPage',
            '@id' => $canonical . '#webpage',
            'url' => $canonical,
            'name' => $siteName,
            'isPartOf' => ['@id' => $canonical . '#website'],
            'description' => $metaDescription,
        ],
        [
            '@type' => 'BreadcrumbList',
            '@id' => $canonical . '#breadcrumb',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Home',
                    'item' => $canonical,
                ],
            ],
        ],
    ],
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

header('Content-Type: text/html; charset=UTF-8');

?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Don't Miss Out: The Latest Trending Stories & Secret Insights</title>
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="shortcut icon" href="/favicon.svg">
  <meta name="description" content="<?= e($metaDescription) ?>">
  <link rel="canonical" href="<?= e($canonical) ?>">
  <meta name="robots" content="index,follow">

  <meta property="og:type" content="website">
  <meta property="og:site_name" content="<?= e($siteName) ?>">
  <meta property="og:title" content="<?= e($pageTitle) ?>">
  <meta property="og:description" content="<?= e($metaDescription) ?>">
  <meta property="og:url" content="<?= e($canonical) ?>">
  <meta property="og:image" content="<?= e($ogImage) ?>">

  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?= e($pageTitle) ?>">
  <meta name="twitter:description" content="<?= e($metaDescription) ?>">
  <meta name="twitter:image" content="<?= e($ogImage) ?>">

  <script type="application/ld+json"><?= $schema !== false ? $schema : '{}' ?></script>

  <style>
    :root{--bg:#0f1218;--bg2:#141a23;--panel:#141b26;--panel2:#101621;--text:#f2f4f7;--muted:#9aa7b6;--muted2:#7b8796;--accent:#ff3b3b;--accent2:#ff3b9a;--border:rgba(255,255,255,.08);--shadow:0 16px 40px rgba(0,0,0,.35)}
    *{box-sizing:border-box}
    html,body{height:100%}
    body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:linear-gradient(180deg,var(--bg),#0b0e14);color:var(--text);line-height:1.55}
    a{color:inherit;text-decoration:none}
    a:hover{text-decoration:underline}
    .container{max-width:1120px;margin:0 auto;padding:0 22px}
    .topbar{background:#0b0e14;border-bottom:1px solid var(--border)}
    .topbar-inner{display:flex;align-items:center;gap:18px;min-height:58px}
    .brand{display:flex;align-items:center;gap:10px;font-weight:800;letter-spacing:.08em}
    .brand .mark{display:flex;align-items:center;gap:4px}
    .chev{width:10px;height:10px;display:inline-block;border-right:3px solid var(--accent);border-top:3px solid var(--accent);transform:skewX(-12deg) rotate(45deg);opacity:.95}
    .nav{margin-left:auto;display:flex;align-items:center;gap:18px;flex-wrap:wrap}
    .nav a{color:#e9eef6;font-size:.86rem;opacity:.95}
    .nav a:hover{opacity:1}
    .tools{display:flex;align-items:center;gap:12px}
    .iconbtn{width:34px;height:34px;border:1px solid var(--border);background:rgba(255,255,255,.02);border-radius:10px;display:grid;place-items:center}
    .iconbtn:hover{background:rgba(255,255,255,.05)}
    .icon{width:18px;height:18px;display:block}

    .catstrip{background:linear-gradient(90deg,#d73232,#ff3b3b,#c03ab6);border-bottom:1px solid rgba(255,255,255,.14)}
    .catstrip-inner{display:flex;gap:14px;align-items:center;min-height:44px;overflow:auto;padding:0 2px}
    .chip{display:flex;align-items:center;gap:10px;color:#fff;font-size:.82rem;font-weight:700;white-space:nowrap;padding:10px 12px}
    .chip .dot{width:5px;height:5px;border-radius:999px;background:rgba(255,255,255,.75)}
    .chip .tag{display:inline-flex;align-items:center;gap:8px}
    .chip .mini{width:10px;height:10px;border:2px solid rgba(255,255,255,.85);border-radius:3px;transform:rotate(45deg)}

    .main{padding:26px 0 34px}
    .grid{display:grid;grid-template-columns:1.55fr .85fr;gap:24px;align-items:start}
    .section-label{display:flex;align-items:center;gap:8px;font-weight:800;font-size:.8rem;letter-spacing:.12em;color:#e9eef6;opacity:.9}
    .section-label .slash{color:var(--accent)}
    .card{background:linear-gradient(180deg,rgba(255,255,255,.03),rgba(255,255,255,.015));border:1px solid var(--border);border-radius:16px;box-shadow:var(--shadow)}
    .featured{padding:16px}
    .kicker{color:var(--accent);font-weight:800;font-size:.78rem;letter-spacing:.06em;margin-bottom:6px;text-transform:uppercase}
    .title{font-size:1.9rem;line-height:1.14;margin:0 0 8px;font-weight:850;letter-spacing:-.01em}
    .meta{color:var(--muted);font-size:.9rem}
    .meta span{color:var(--muted2)}
    .thumbs{display:grid;grid-template-columns:1.2fr .8fr;gap:10px;margin:12px 0 14px}
    .thumbs .left{border-radius:14px;overflow:hidden;border:1px solid var(--border);background:#0b0e14}
    .thumbs .right{display:grid;grid-template-rows:1fr 1fr;gap:10px}
    .thumbs img{width:100%;height:100%;object-fit:cover;display:block;filter:saturate(.9) contrast(1.02)}

    .popular{padding:16px}
    .plist{display:flex;flex-direction:column;gap:14px;margin-top:12px}
    .pitem{display:grid;grid-template-columns:88px 1fr;gap:12px;align-items:center}
    .pimg{width:88px;height:66px;border-radius:12px;overflow:hidden;border:1px solid var(--border);background:#0b0e14}
    .pimg img{width:100%;height:100%;object-fit:cover;display:block}
    .ptag{color:var(--accent);font-weight:800;font-size:.74rem;letter-spacing:.04em;text-transform:uppercase}
    .ptitle{margin:4px 0 6px;font-weight:800;line-height:1.2}
    .pmeta{color:var(--muted);font-size:.84rem}

    .divider{height:56px;background:linear-gradient(180deg,transparent,rgba(255,255,255,.02),transparent);margin:22px 0}
    .latest{padding:18px 0 44px}
    .latest-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
    .latest-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px}
    .post{background:linear-gradient(180deg,rgba(255,255,255,.03),rgba(255,255,255,.015));border:1px solid var(--border);border-radius:16px;overflow:hidden}
    .post img{width:100%;height:180px;object-fit:cover;display:block;background:#0b0e14}
    .post-body{padding:14px 14px 16px}
    .post .ptag{margin-bottom:6px}
    .post .ptitle{font-size:1.05rem;margin:0 0 8px}
    .loadmore{display:flex;justify-content:center;margin-top:18px}
    .btn{display:inline-flex;align-items:center;gap:10px;border:1px solid var(--border);border-radius:999px;padding:10px 14px;background:rgba(255,255,255,.03);text-decoration:none;color:var(--text);font-weight:800}
    .btn:hover{background:rgba(255,255,255,.06)}

    .footer{border-top:1px solid var(--border);padding:18px 0 26px;color:var(--muted);font-size:.9rem}
    .footer-inner{display:flex;gap:14px;align-items:center;justify-content:space-between;flex-wrap:wrap}
    .footer a{color:var(--muted)}
    .footer a:hover{color:var(--text)}

    @media (max-width:980px){.grid{grid-template-columns:1fr}.latest-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.title{font-size:1.7rem}}
    @media (max-width:640px){.latest-grid{grid-template-columns:1fr}.thumbs{grid-template-columns:1fr}.thumbs .right{grid-template-columns:1fr 1fr;grid-template-rows:auto}.nav{display:none}.title{font-size:1.5rem}}
  </style>
</head>
<body>
  <header class="topbar">
    <div class="container">
      <div class="topbar-inner">
        <a class="brand" href="/">
          <span><?= e($siteName) ?></span>
          <a href="/home">Home</a>


        <nav class="nav" aria-label="Primary">
          <a href="/dmca">Dmca</a>
          <a href="/contact">Contact</a>
          <a href="/privacy-policy">Privacy Policy</a>
          <a href="/copyright">Copyright</a>
          <a href="/authors">Authors</a>
          <a href="sitemap.xml">Sitemap</a>
        </nav>

        <div class="tools" aria-label="Tools">
          <a class="iconbtn" href="<?= e(content_href($contentScript, 'latest')) ?>" aria-label="Settings">
            <svg class="icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z" stroke="currentColor" stroke-width="2"/>
              <path d="M19.4 15a7.8 7.8 0 0 0 .1-1l2-1.2-2-3.6-2.3.4a7.7 7.7 0 0 0-1.6-1l-.4-2.3H11l-.4 2.3a7.7 7.7 0 0 0-1.6 1l-2.3-.4-2 3.6 2 1.2a7.8 7.8 0 0 0 0 2l-2 1.2 2 3.6 2.3-.4a7.7 7.7 0 0 0 1.6 1l.4 2.3h4.1l.4-2.3a7.7 7.7 0 0 0 1.6-1l2.3.4 2-3.6-2-1.2Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
            </svg>
          </a>
          <a class="iconbtn" href="<?= e(content_href($contentScript, 'search')) ?>" aria-label="Search">
            <svg class="icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <path d="M10.5 18a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15Z" stroke="currentColor" stroke-width="2"/>
              <path d="M16.2 16.2 21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </a>
        </div>
      </div>
    </div>
  </header>

  <div class="catstrip" aria-label="Categories">
    <div class="container">
      <div class="catstrip-inner">
        <?php foreach ($categories as $i => $cat): ?>
          <a class="chip" href="<?= e(content_href($contentScript, slugify($cat) !== '' ? slugify($cat) : $cat)) ?>">
            <span class="tag"><span class="mini" aria-hidden="true"></span><?= e($cat) ?></span>
            <?php if ($i < count($categories) - 1): ?>
              <span class="dot" aria-hidden="true"></span>
            <?php endif; ?>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <main class="main">
    <div class="container">
      <div class="grid">
        <section aria-label="Featured">
          <div class="section-label"><span class="slash">/</span> FEATURED POST</div>
              <div style="text-align: center; margin: 20px 0;">
          <?php include 'banner.html'; ?>
        <div style="text-align: center; margin: 20px 0;">
          <?php include 'visitor.html'; ?>
          <article class="card featured" style="margin-top:10px">
            <div class="kicker"><?= e($featured['category']) ?></div>
            <h1 class="title"><a href="<?= e(content_href($contentScript, (string) $featured['q'])) ?>"><?= e($featured['title']) ?></a></h1>
            <div class="meta">By <span><?= e($featured['author']) ?></span> - <?= e($featured['date']) ?></div>

            <a class="thumbs" href="<?= e(content_href($contentScript, (string) $featured['q'])) ?>" aria-label="Open featured">
              <div class="left">
                <img src="<?= e($featured['images'][0]) ?>" alt="Featured image" loading="lazy" decoding="async" referrerpolicy="no-referrer">
              </div>
              <div class="right">
                <div class="left" style="border-radius:14px">
                  <img src="<?= e($featured['images'][1]) ?>" alt="Featured image" loading="lazy" decoding="async" referrerpolicy="no-referrer">
                </div>
                <div class="left" style="border-radius:14px">
                  <img src="<?= e($featured['images'][2]) ?>" alt="Featured image" loading="lazy" decoding="async" referrerpolicy="no-referrer">
                </div>
              </div>
            </a>
          </article>
        </section>

        <aside aria-label="Popular">
          <div class="section-label"><span class="slash">/</span> POPULAR</div>
          <div class="card popular" style="margin-top:10px">
            <div class="plist">
              <?php foreach ($popular as $p): ?>
                <a class="pitem" href="<?= e(content_href($contentScript, (string) $p['q'])) ?>">
                  <div class="pimg"><img src="<?= e($p['image']) ?>" alt="Popular thumbnail" loading="lazy" decoding="async" referrerpolicy="no-referrer"></div>
                  <div>
                    <div class="ptag"><?= e($p['category']) ?></div>
                    <div class="ptitle"><?= e($p['title']) ?></div>
                    <div class="pmeta">By <?= e($p['author']) ?> - <?= e($p['date']) ?></div>
                  </div>
                </a>
              <?php endforeach; ?>
            </div>
          </div>
        </aside>
      </div>

      <div class="divider" role="separator" aria-hidden="true"></div>

      <section id="latest" class="latest" aria-label="Latest">
        <div class="latest-head">
          <div class="section-label"><span class="slash">/</span> LATEST POSTS</div>
          <a class="meta" href="sitemap.xml">Browse sitemap →</a>
        </div>

        <div class="latest-grid">
          <?php foreach ($latest as $p): ?>
            <article class="post">
              <a href="<?= e(content_href($contentScript, (string) $p['q'])) ?>">
                <img src="<?= e($p['image']) ?>" alt="Latest thumbnail" loading="lazy" decoding="async" referrerpolicy="no-referrer">
              </a>
              <div class="post-body">
                <div class="ptag"><?= e($p['category']) ?></div>
                <h2 class="ptitle"><a href="<?= e(content_href($contentScript, (string) $p['q'])) ?>"><?= e($p['title']) ?></a></h2>
                <div class="pmeta">By <?= e($p['author']) ?> - <?= e($p['date']) ?></div>
              </div>
            </article>
          <?php endforeach; ?>
        </div>

      </section>
    </div>
  </main>

  <footer class="footer">
    <div class="container">
      <div class="footer-inner">
        <div>© <?= e((string) date('Y')) ?> <?= e($siteName) ?></div>
        <div style="display:flex;gap:14px;flex-wrap:wrap">
          <a href="/dmca">DMCA</a>
          <a href="/privacy-policy">Privacy</a>
          <a href="/copyright">Copyright</a>
          <a href="/authors">Authors</a>
          <a href="/contact">Contact</a>
          <a href="robots.txt">Robots</a>
        </div>
      </div>
    </div>
  </footer>
</body>
</html>
