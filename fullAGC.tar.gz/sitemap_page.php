<?php

declare(strict_types=1);

require_once __DIR__ . '/schema.php';

function sitemap_cache_enabled(): bool
{
    $v = env_get('SITEMAP_CACHE_ENABLED', '1');
    $v = strtolower(trim((string) $v));
    return $v === '1' || $v === 'true' || $v === 'yes' || $v === 'on';
}

function sitemap_cache_ttl(): int
{
    $v = env_get('SITEMAP_CACHE_TTL', '21600');
    $n = is_numeric($v) ? (int) $v : 21600;
    return max(60, $n);
}

function sitemap_cache_dir(): string
{
    $v = trim((string) (env_get('SITEMAP_CACHE_DIR', 'cache/sitemaps') ?? 'cache/sitemaps'));
    return $v !== '' ? $v : 'cache/sitemaps';
}

function sitemap_cache_file(string $name): string
{
    $safe = preg_replace('/[^a-z0-9._-]/i', '-', $name) ?? 'sitemap.xml';
    $dir = rtrim(__DIR__ . '/' . trim(sitemap_cache_dir(), '/\\'), '/\\');
    return $dir . '/' . $safe;
}

function sitemap_cache_try_serve(string $cacheFile, int $ttlSeconds): bool
{
    if (!is_file($cacheFile)) {
        return false;
    }
    $age = time() - (int) filemtime($cacheFile);
    if ($age < 0 || $age > $ttlSeconds) {
        return false;
    }
    header('Content-Type: application/xml; charset=UTF-8');
    readfile($cacheFile);
    return true;
}

function sitemap_cache_write(string $cacheFile, string $xml): void
{
    $dir = dirname($cacheFile);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $tmp = $cacheFile . '.tmp';
    @file_put_contents($tmp, $xml);
    @rename($tmp, $cacheFile);
}

function sitemap_escape(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function sitemap_slugify(string $text): string
{
    $text = trim($text);
    if ($text === '') {
        return '';
    }
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
        if (is_string($converted) && $converted !== '') {
            $text = $converted;
        }
    }
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9\s-]/', '', $text) ?? '';
    $text = preg_replace('/[\s-]+/', '-', $text) ?? '';
    $text = trim($text, '-');
    return $text;
}

function sitemap_load_slugs(string $keywordsFile): array
{
    $out = [];
    $seen = [];

    if (is_file($keywordsFile)) {
        $lines = file($keywordsFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (is_array($lines)) {
            foreach ($lines as $line) {
                $kw = trim((string) $line);
                if ($kw === '') {
                    continue;
                }
                $slug = sitemap_slugify($kw);
                if ($slug === '') {
                    continue;
                }
                if (isset($seen[$slug])) {
                    continue;
                }
                $seen[$slug] = true;
                $out[] = $slug;
            }
        }
    }

    return $out;
}

function sitemap_is_crawler(string $ua): bool
{
    $ua = strtolower(trim($ua));
    if ($ua === '') {
        return false;
    }
    return (bool) preg_match('/\b(googlebot|bingbot|duckduckbot|slurp|yandex(bot)?|baiduspider|sogou|seznambot|ia_archiver)\b/i', $ua);
}

$page = 1;
if (isset($_GET['page'])) {
    $p = (string) $_GET['page'];
    if (ctype_digit($p)) {
        $page = max(1, (int) $p);
    }
}

$base = seo_base_url();
$homeUrl = rtrim($base, '/') . '/';
$contentBase = $homeUrl . 'super-updates/';
$today = gmdate('Y-m-d');

$redirectEnabled = env_get('SITEMAP_VISITOR_REDIRECT_ENABLED', '1');
$redirectEnabled = $redirectEnabled === '1' || strtolower((string) $redirectEnabled) === 'true' || strtolower((string) $redirectEnabled) === 'yes';
$visitorRedirect = env_get('SITEMAP_VISITOR_REDIRECT', '/') ?? '/';

if ($redirectEnabled) {
    $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
    if (!sitemap_is_crawler($ua)) {
        header('Location: ' . $visitorRedirect, true, 302);
        exit;
    }
}

$sitemapPageCacheFile = sitemap_cache_file('sitemap-' . $page . '.xml');
$sitemapCacheTtl = sitemap_cache_ttl();
$bypassCache = isset($_GET['refresh']) && (string) $_GET['refresh'] === '1';
if (!$bypassCache && sitemap_cache_enabled()) {
    if (sitemap_cache_try_serve($sitemapPageCacheFile, $sitemapCacheTtl)) {
        exit;
    }
}

$slugs = sitemap_load_slugs(__DIR__ . '/sitemap_keywords.txt');

$perSitemap = 1000;
$firstPageSlugs = $perSitemap - 1;
$totalSlugs = count($slugs);
$totalPages = 1;
if ($totalSlugs > $firstPageSlugs) {
    $totalPages = 1 + (int) ceil(($totalSlugs - $firstPageSlugs) / $perSitemap);
}

if ($page > $totalPages) {
    $page = $totalPages;
}

$sliceStart = 0;
$sliceLen = $perSitemap;
if ($page === 1) {
    $sliceStart = 0;
    $sliceLen = $firstPageSlugs;
} else {
    $sliceStart = $firstPageSlugs + (($page - 2) * $perSitemap);
    $sliceLen = $perSitemap;
}

$slice = array_slice($slugs, $sliceStart, $sliceLen);

header('Content-Type: application/xml; charset=UTF-8');

if (sitemap_cache_enabled() && !$bypassCache && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    ob_start();
}

echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";

if ($page === 1) {
    echo "  <url>\n";
    echo "    <loc>" . sitemap_escape($homeUrl) . "</loc>\n";
    echo "    <lastmod>" . sitemap_escape($today) . "</lastmod>\n";
    echo "    <changefreq>daily</changefreq>\n";
    echo "    <priority>1.0</priority>\n";
    echo "  </url>\n";
}

foreach ($slice as $slug) {
    $loc = $contentBase . rawurlencode($slug);
    echo "  <url>\n";
    echo "    <loc>" . sitemap_escape($loc) . "</loc>\n";
    echo "    <lastmod>" . sitemap_escape($today) . "</lastmod>\n";
    echo "    <changefreq>daily</changefreq>\n";
    echo "    <priority>0.6</priority>\n";
    echo "  </url>\n";
}

echo "</urlset>\n";

if (sitemap_cache_enabled() && !$bypassCache && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $xml = (string) ob_get_contents();
    ob_end_flush();
    sitemap_cache_write($sitemapPageCacheFile, $xml);
}
