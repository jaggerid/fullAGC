<?php

declare(strict_types=1);

if (is_file(__DIR__ . '/env.php')) {
    require_once __DIR__ . '/env.php';
    env_load(__DIR__ . '/.env');
}

function seo_env_bool(string $key, bool $default = false): bool
{
    $v = env_get($key, $default ? '1' : '0');
    $v = strtolower(trim((string) $v));
    return $v === '1' || $v === 'true' || $v === 'yes' || $v === 'on';
}

function seo_env_list(string $key): array
{
    $raw = (string) (env_get($key, '') ?? '');
    if ($raw === '') {
        return [];
    }
    $parts = array_map('trim', explode(',', $raw));
    return array_values(array_filter($parts, static fn($v) => $v !== ''));
}

function seo_apply_ua_block(): void
{
    if (!seo_env_bool('UA_BLOCK_ENABLED', false)) {
        return;
    }
    $pattern = trim((string) (env_get('UA_BLOCK_REGEX', '') ?? ''));
    if ($pattern === '') {
        return;
    }
    $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ($ua === '') {
        return;
    }
    $ok = @preg_match('/(?:' . $pattern . ')/i', $ua);
    if ($ok !== 1) {
        return;
    }

    $action = strtolower(trim((string) (env_get('UA_BLOCK_ACTION', 'deny') ?? 'deny')));
    if ($action === 'page') {
        $pagePath = trim((string) (env_get('UA_BLOCK_PAGE', '/blocked') ?? '/blocked'));
        if ($pagePath === '') {
            $pagePath = '/blocked';
        }
        if ($pagePath[0] !== '/') {
            $pagePath = '/' . $pagePath;
        }
        if (seo_request_path() === $pagePath) {
            return;
        }
        header('Location: ' . $pagePath, true, 302);
        exit;
    }

    http_response_code(403);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Forbidden';
    exit;
}

function seo_apply_site_redirect(): void
{
    if (!seo_env_bool('SITE_REDIRECT_ENABLED', false)) {
        return;
    }

    $target = trim((string) (env_get('SITE_REDIRECT_URL', '') ?? ''));
    if ($target === '') {
        return;
    }

    $path = seo_request_path();
    $excluded = seo_env_list('SITE_REDIRECT_EXCLUDE_PATHS');
    foreach ($excluded as $ex) {
        if ($ex === $path) {
            return;
        }
    }

    $allowIps = seo_env_list('SITE_REDIRECT_ALLOW_IPS');
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    if ($ip !== '' && in_array($ip, $allowIps, true)) {
        return;
    }

    header('Location: ' . $target, true, 302);
    exit;
}

seo_apply_ua_block();
seo_apply_site_redirect();

function seo_detect_scheme(): string
{
    $https = $_SERVER['HTTPS'] ?? '';
    if (!empty($https) && $https !== 'off') {
        return 'https';
    }
    if (isset($_SERVER['SERVER_PORT']) && (string) $_SERVER['SERVER_PORT'] === '443') {
        return 'https';
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
        $p = strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']);
        if ($p === 'https') {
            return 'https';
        }
    }
    return 'http';
}

function seo_detect_host(): string
{
    $host = (string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost');
    $host = preg_replace('/[^a-z0-9\-\.:]/i', '', $host) ?? 'localhost';
    return $host !== '' ? $host : 'localhost';
}

function seo_base_url(): string
{
    return seo_detect_scheme() . '://' . seo_detect_host();
}

function seo_request_path(): string
{
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
    $path = strtok($uri, '?');
    $path = is_string($path) && $path !== '' ? $path : '/';
    if ($path[0] !== '/') {
        $path = '/' . $path;
    }
    return $path;
}

function seo_schema_jsonld(array $data): string
{
    $baseUrl = (string) ($data['baseUrl'] ?? seo_base_url());
    $canonical = (string) ($data['canonical'] ?? ($baseUrl . seo_request_path()));
    $host = (string) ($data['host'] ?? seo_detect_host());
    $siteName = (string) ($data['siteName'] ?? $host);
    $headline = (string) ($data['headline'] ?? '');
    $description = (string) ($data['description'] ?? '');
    $datePublished = (string) ($data['datePublished'] ?? '');
    $dateModified = (string) ($data['dateModified'] ?? $datePublished);
    $keywords = (string) ($data['keywords'] ?? '');
    $images = $data['images'] ?? [];
    if (!is_array($images)) {
        $images = [];
    }

    $graph = [];
    $graph[] = [
        '@type' => 'WebSite',
        '@id' => $baseUrl . '/#website',
        'url' => $baseUrl . '/',
        'name' => $siteName,
    ];

    $graph[] = [
        '@type' => 'WebPage',
        '@id' => $canonical . '#webpage',
        'url' => $canonical,
        'name' => $headline !== '' ? $headline : $siteName,
        'isPartOf' => ['@id' => $baseUrl . '/#website'],
        'description' => $description,
        'inLanguage' => (string) ($data['inLanguage'] ?? 'en'),
    ];

    $article = [
        '@type' => 'Article',
        '@id' => $canonical . '#article',
        'mainEntityOfPage' => ['@id' => $canonical . '#webpage'],
        'headline' => $headline,
        'description' => $description,
        'datePublished' => $datePublished,
        'dateModified' => $dateModified,
        'inLanguage' => (string) ($data['inLanguage'] ?? 'en'),
        'keywords' => $keywords,
        'author' => [
            '@type' => 'Organization',
            'name' => $siteName,
            'url' => $baseUrl . '/',
        ],
        'publisher' => [
            '@type' => 'Organization',
            'name' => $siteName,
            'url' => $baseUrl . '/',
        ],
    ];
    if (count($images) > 0) {
        $article['image'] = array_values(array_filter(array_map(function ($u) {
            $u = trim((string) $u);
            return $u !== '' ? $u : null;
        }, $images)));
    }
    $graph[] = $article;

    $payload = [
        '@context' => 'https://schema.org',
        '@graph' => $graph,
    ];

    $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    return is_string($json) ? $json : '{}';
}

function seo_schema_news_breadcrumb_jsonld(array $data): string
{
    $baseUrl = (string) ($data['baseUrl'] ?? seo_base_url());
    $canonical = (string) ($data['canonical'] ?? ($baseUrl . seo_request_path()));
    $host = (string) ($data['host'] ?? seo_detect_host());
    $siteName = (string) ($data['siteName'] ?? $host);
    $headline = (string) ($data['headline'] ?? '');
    $description = (string) ($data['description'] ?? '');
    $datePublished = (string) ($data['datePublished'] ?? '');
    $dateModified = (string) ($data['dateModified'] ?? $datePublished);
    $images = $data['images'] ?? [];
    if (!is_array($images)) {
        $images = [];
    }

    $imageList = array_values(array_filter(array_map(function ($u) {
        $u = trim((string) $u);
        return $u !== '' ? $u : null;
    }, $images)));

    $logoUrl = $imageList[0] ?? (string) ($data['logoUrl'] ?? '');

    $authorName = (string) ($data['authorName'] ?? $siteName);
    $authorJobTitle = (string) ($data['authorJobTitle'] ?? 'Editor');

    $ratingValue = $data['ratingValue'] ?? null;
    $ratingCount = $data['ratingCount'] ?? null;
    $bestRating = $data['bestRating'] ?? 5;
    $worstRating = $data['worstRating'] ?? 1;

    $ratingValueF = is_numeric($ratingValue) ? (float) $ratingValue : null;
    $ratingCountI = is_numeric($ratingCount) ? (int) $ratingCount : null;
    $bestRatingF = is_numeric($bestRating) ? (float) $bestRating : 5.0;
    $worstRatingF = is_numeric($worstRating) ? (float) $worstRating : 1.0;

    $hasRating = $ratingValueF !== null && $ratingCountI !== null
        && $ratingCountI >= 1
        && $bestRatingF > $worstRatingF
        && $ratingValueF >= $worstRatingF
        && $ratingValueF <= $bestRatingF;

    $articleType = (string) ($data['articleType'] ?? 'NewsArticle');
    $breadcrumbSectionName = (string) ($data['breadcrumbSectionName'] ?? 'News');
    $breadcrumbSectionUrl = (string) ($data['breadcrumbSectionUrl'] ?? $canonical);

    $article = [
            '@context' => 'https://schema.org',
            '@type' => $articleType,
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id' => $canonical,
            ],
            'headline' => $headline,
            'description' => $description,
            'author' => [
                '@type' => 'Person',
                'name' => $authorName,
                'jobTitle' => $authorJobTitle,
            ],
            'publisher' => [
                '@type' => 'Organization',
                'name' => $siteName,
            ],
            'datePublished' => $datePublished,
            'dateModified' => $dateModified,
    ];

    if (count($imageList) > 0) {
        $article['image'] = $imageList;
    }

    if ($logoUrl !== '') {
        $article['publisher']['logo'] = [
            '@type' => 'ImageObject',
            'url' => $logoUrl,
        ];
    }

    if ($hasRating) {
        $article['aggregateRating'] = [
            '@type' => 'AggregateRating',
            'ratingValue' => $ratingValueF,
            'ratingCount' => $ratingCountI,
            'bestRating' => $bestRatingF,
            'worstRating' => $worstRatingF,
        ];
    }

    $homeUrl = rtrim($baseUrl, '/') . '/';
    $breadcrumb = [
        '@type' => 'BreadcrumbList',
        '@id' => $canonical . '#breadcrumb',
        'itemListElement' => [
            [
                '@type' => 'ListItem',
                'position' => 1,
                'name' => 'Home',
                'item' => $homeUrl,
            ],
            [
                '@type' => 'ListItem',
                'position' => 2,
                'name' => $breadcrumbSectionName,
                'item' => $breadcrumbSectionUrl,
            ],
        ],
    ];

    $graph = [];
    $graph[] = [
        '@type' => 'WebSite',
        '@id' => $homeUrl . '#website',
        'url' => $homeUrl,
        'name' => $siteName,
    ];
    $graph[] = $breadcrumb;
    $graph[] = $article;

    $payload = [
        '@context' => 'https://schema.org',
        '@graph' => $graph,
    ];

    $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    return is_string($json) ? $json : '{}';
}

