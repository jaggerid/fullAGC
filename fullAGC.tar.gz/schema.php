<?php

declare(strict_types=1);

if (is_file(__DIR__ . '/env.php')) {
    require_once __DIR__ . '/env.php';
    env_load(__DIR__ . '/.env');
}

/**
 * Common Helpers
 */
function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function random_user_agent(): string
{
    $agents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0',
    ];
    return $agents[array_rand($agents)];
}

function slugify(string $text): string
{
    $text = trim($text);
    if ($text === '') {
        return '';
    }
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
        if (is_string($converted) && $converted !== '') {
            $text = $converted;
        }
    }
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9\s-]/', '', $text) ?? '';
    $text = preg_replace('/[\s-]+/', '-', $text) ?? '';
    return trim($text, '-');
}

function http_get(string $url, int $timeoutSeconds = 12, ?string $proxy = null): array
{
    $ua = random_user_agent();
    $headers = [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language: en-US,en;q=0.9,id-ID;q=0.8,id;q=0.7',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
        'DNT: 1',
        'Upgrade-Insecure-Requests: 1',
    ];

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => $timeoutSeconds,
            CURLOPT_TIMEOUT => $timeoutSeconds,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => $ua,
            CURLOPT_ENCODING => '',
            CURLOPT_HTTPHEADER => $headers,
        ]);

        if ($proxy !== null && $proxy !== '') {
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
        }

        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($errno !== 0 || $body === false) {
            return [
                'ok' => false,
                'status' => $status,
                'error' => $error !== '' ? $error : ('cURL error #' . $errno),
                'body' => '',
            ];
        }

        return [
            'ok' => $status >= 200 && $status < 300,
            'status' => $status,
            'error' => '',
            'body' => (string) $body,
        ];
    }

    $httpOpts = [
        'method' => 'GET',
        'timeout' => $timeoutSeconds,
        'header' => implode("\r\n", array_merge([
            'User-Agent: ' . $ua,
        ], $headers)),
    ];

    if ($proxy !== null && $proxy !== '') {
        $httpOpts['proxy'] = $proxy;
        $httpOpts['request_fulluri'] = true;
    }

    $context = stream_context_create([
        'http' => $httpOpts,
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);

    $body = @file_get_contents($url, false, $context);
    $status = 0;
    if (isset($http_response_header) && is_array($http_response_header)) {
        foreach ($http_response_header as $line) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $m)) {
                $status = (int) $m[1];
                break;
            }
        }
    }

    if ($body === false) {
        return [
            'ok' => false,
            'status' => $status,
            'error' => 'Request gagal (file_get_contents).',
            'body' => '',
        ];
    }

    return [
        'ok' => $status >= 200 && $status < 300,
        'status' => $status,
        'error' => '',
        'body' => (string) $body,
    ];
}

function http_get_with_headers(string $url, array $extraHeaders, int $timeoutSeconds = 12, ?string $proxy = null): array
{
    $ua = random_user_agent();
    $headers = [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language: en-US,en;q=0.9,id-ID;q=0.8,id;q=0.7',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
        'DNT: 1',
        'Upgrade-Insecure-Requests: 1',
    ];

    foreach ($extraHeaders as $h) {
        $h = trim((string) $h);
        if ($h !== '') {
            $headers[] = $h;
        }
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => $timeoutSeconds,
            CURLOPT_TIMEOUT => $timeoutSeconds,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => $ua,
            CURLOPT_ENCODING => '',
            CURLOPT_HTTPHEADER => $headers,
        ]);

        if ($proxy !== null && $proxy !== '') {
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
        }

        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($errno !== 0 || $body === false) {
            return [
                'ok' => false,
                'status' => $status,
                'error' => $error !== '' ? $error : ('cURL error #' . $errno),
                'body' => '',
            ];
        }

        return [
            'ok' => $status >= 200 && $status < 300,
            'status' => $status,
            'error' => '',
            'body' => (string) $body,
        ];
    }

    $httpOpts = [
        'method' => 'GET',
        'timeout' => $timeoutSeconds,
        'header' => implode("\r\n", array_merge([
            'User-Agent: ' . $ua,
        ], $headers)),
    ];

    if ($proxy !== null && $proxy !== '') {
        $httpOpts['proxy'] = $proxy;
        $httpOpts['request_fulluri'] = true;
    }

    $context = stream_context_create([
        'http' => $httpOpts,
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);

    $body = @file_get_contents($url, false, $context);
    $status = 0;
    if (isset($http_response_header) && is_array($http_response_header)) {
        foreach ($http_response_header as $line) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $m)) {
                $status = (int) $m[1];
                break;
            }
        }
    }

    if ($body === false) {
        return [
            'ok' => false,
            'status' => $status,
            'error' => 'Request gagal (file_get_contents).',
            'body' => '',
        ];
    }

    return [
        'ok' => $status >= 200 && $status < 300,
        'status' => $status,
        'error' => '',
        'body' => (string) $body,
    ];
}

function http_get_binary(string $url, int $timeoutSeconds = 12): array
{
    $ua = random_user_agent();
    $headers = [
        'Accept: image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
        'Accept-Language: en-US,en;q=0.9',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
        'DNT: 1',
    ];

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => $timeoutSeconds,
            CURLOPT_TIMEOUT => $timeoutSeconds,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => $ua,
            CURLOPT_ENCODING => '',
            CURLOPT_HTTPHEADER => $headers,
        ]);
        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $ctype = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);

        if ($errno !== 0 || $body === false) {
            return [
                'ok' => false,
                'status' => $status,
                'content_type' => $ctype,
                'error' => $error !== '' ? $error : ('cURL error #' . $errno),
                'body' => '',
            ];
        }

        return [
            'ok' => $status >= 200 && $status < 300,
            'status' => $status,
            'content_type' => $ctype,
            'error' => '',
            'body' => (string) $body,
        ];
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => $timeoutSeconds,
            'header' => implode("\r\n", array_merge([
                'User-Agent: ' . $ua,
            ], $headers)),
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);

    $body = @file_get_contents($url, false, $context);
    $status = 0;
    $ctype = '';
    if (isset($http_response_header) && is_array($http_response_header)) {
        foreach ($http_response_header as $line) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $m)) {
                $status = (int) $m[1];
            }
            if (stripos($line, 'content-type:') === 0) {
                $ctype = trim(substr($line, strlen('content-type:')));
            }
        }
    }

    if ($body === false) {
        return [
            'ok' => false,
            'status' => $status,
            'content_type' => $ctype,
            'error' => 'Request gagal (file_get_contents).',
            'body' => '',
        ];
    }

    return [
        'ok' => $status >= 200 && $status < 300,
        'status' => $status,
        'content_type' => $ctype,
        'error' => '',
        'body' => (string) $body,
    ];
}

function bing_image_search(string $keyword, int $limit = 3): array
{
    $q = rawurlencode($keyword);
    $endpoints = [
        'https://www.bing.com/images/async?q=' . $q . '&first=0&count=35&adlt=off',
        'https://www.bing.com/images/search?q=' . $q . '&first=0&count=35&adlt=off&form=HDRSC2',
    ];

    $images = [];
    $seen = [];
    $lastStatus = 0;
    $lastErr = '';

    foreach ($endpoints as $url) {
        $res = http_get_with_headers($url, [
            'Referer: https://www.bing.com/',
            'Origin: https://www.bing.com',
        ], 14);
        $lastStatus = (int) ($res['status'] ?? 0);
        if (!$res['ok'] || ($res['body'] ?? '') === '') {
            $lastErr = (string) ($res['error'] ?? '');
            continue;
        }

        $html = (string) $res['body'];
        if (stripos($html, 'captcha') !== false || stripos($html, 'blocked') !== false) {
            return [
                'ok' => false,
                'status' => $lastStatus,
                'error' => 'Scraper terblokir atau memerlukan verifikasi (CAPTCHA).',
                'images' => [],
            ];
        }

        if (preg_match_all('/\biusc\b[\s\S]{0,1200}?\bm=(["\'])(.*?)\1/i', $html, $matches)) {
            $raws = $matches[2] ?? [];
            foreach ($raws as $raw) {
                if (count($images) >= $limit) {
                    break;
                }
                $json = html_entity_decode((string) $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $data = json_decode($json, true);
                if (!is_array($data)) {
                    continue;
                }
                $turl = trim((string) ($data['turl'] ?? ''));
                $murl = trim((string) ($data['murl'] ?? ''));
                $pick = '';

                if ($turl !== '' && preg_match('#^https?://#i', $turl) && preg_match('#\b(bing\.com|mm\.bing\.net)\b#i', $turl)) {
                    $pick = $turl;
                } elseif ($murl !== '' && preg_match('#^https?://#i', $murl) && preg_match('#\b(bing\.com|mm\.bing\.net)\b#i', $murl)) {
                    $pick = $murl;
                }

                if ($pick === '' || isset($seen[$pick])) {
                    continue;
                }

                $seen[$pick] = true;
                $images[] = $pick;
            }
        }

        if (count($images) < $limit) {
            if (preg_match_all('/<img[^>]+(?:data-src|src)=(["\'])(.*?)\1/i', $html, $im)) {
                $srcs = $im[2] ?? [];
                foreach ($srcs as $src) {
                    if (count($images) >= $limit) {
                        break;
                    }
                    $src = html_entity_decode((string) $src, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    $src = trim((string) preg_replace('/\s+.*/', '', $src));
                    if ($src === '' || isset($seen[$src])) {
                        continue;
                    }
                    if (stripos($src, 'data:image') === 0) {
                        continue;
                    }
                    if (!preg_match('#^https?://#i', $src)) {
                        continue;
                    }
                    if (!preg_match('#\b(bing\.com|mm\.bing\.net)\b#i', $src)) {
                        continue;
                    }
                    $seen[$src] = true;
                    $images[] = $src;
                }
            }
        }

        if (count($images) >= $limit) {
            break;
        }
    }

    if (count($images) === 0) {
        return [
            'ok' => false,
            'status' => $lastStatus,
            'error' => $lastErr !== '' ? $lastErr : 'Tidak ada gambar yang bisa diambil. Coba keyword lain.',
            'images' => [],
        ];
    }

    return [
        'ok' => true,
        'status' => $lastStatus,
        'error' => '',
        'images' => array_slice($images, 0, $limit),
    ];
}

function bing_image_search_cached(string $keyword, int $limit, int $ttlSeconds = 21600): array
{
    $cacheDir = __DIR__ . '/cache';
    if (!is_dir($cacheDir)) {
        @mkdir($cacheDir, 0775, true);
    }

    $key = sha1('v2|' . strtolower(trim($keyword)) . '|' . $limit);
    $cacheFile = $cacheDir . '/bing_' . $key . '.json';

    if (is_file($cacheFile)) {
        $age = time() - (int) filemtime($cacheFile);
        if ($age >= 0 && $age < $ttlSeconds) {
            $raw = file_get_contents($cacheFile);
            $data = is_string($raw) ? json_decode($raw, true) : null;
            if (is_array($data) && isset($data['images']) && is_array($data['images'])) {
                return [
                    'ok' => (bool) ($data['ok'] ?? false),
                    'status' => (int) ($data['status'] ?? 200),
                    'error' => (string) ($data['error'] ?? ''),
                    'images' => array_slice((array) $data['images'], 0, $limit),
                ];
            }
        }
    }

    $res = bing_image_search($keyword, $limit);
    @file_put_contents($cacheFile, json_encode($res, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    return $res;
}

function img_cache_enabled(): bool
{
    $v = env_get('IMG_CACHE_ENABLED', '1');
    $v = strtolower(trim((string) $v));
    return $v === '1' || $v === 'true' || $v === 'yes' || $v === 'on';
}

function img_cache_ttl(): int
{
    $v = env_get('IMG_CACHE_TTL', '1209600');
    $n = is_numeric($v) ? (int) $v : 1209600;
    return max(60, $n);
}

function img_cache_dir(): string
{
    $v = trim((string) (env_get('IMG_CACHE_DIR', 'img/bing') ?? 'img/bing'));
    return $v !== '' ? $v : 'img/bing';
}

function img_cache_extension_from_content_type(string $contentType, string $url): string
{
    $ct = strtolower(trim(explode(';', $contentType)[0] ?? ''));
    $map = [
        'image/jpeg' => 'jpg',
        'image/jpg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
        'image/avif' => 'avif',
        'image/svg+xml' => 'svg',
    ];
    if (isset($map[$ct])) {
        return $map[$ct];
    }
    $path = parse_url($url, PHP_URL_PATH);
    $ext = is_string($path) ? strtolower(pathinfo($path, PATHINFO_EXTENSION)) : '';
    if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif'], true)) {
        return $ext === 'jpeg' ? 'jpg' : $ext;
    }
    return 'jpg';
}

function img_cache_bing_url(string $remoteUrl): string
{
    $remoteUrl = trim($remoteUrl);
    if ($remoteUrl === '' || !preg_match('#^https?://#i', $remoteUrl)) {
        return $remoteUrl;
    }
    if (!img_cache_enabled()) {
        return $remoteUrl;
    }

    $dirRel = trim(img_cache_dir(), '/\\');
    $dirAbs = rtrim(__DIR__ . '/' . $dirRel, '/\\');
    if (!is_dir($dirAbs)) {
        @mkdir($dirAbs, 0775, true);
    }

    $hash = sha1($remoteUrl);
    $ttl = img_cache_ttl();

    $existing = glob($dirAbs . '/' . $hash . '.*');
    if (is_array($existing) && count($existing) > 0) {
        $path = (string) $existing[0];
        $age = time() - (int) filemtime($path);
        if ($age >= 0 && $age < $ttl) {
            $rel = '/' . $dirRel . '/' . basename($path);
            return str_replace('\\', '/', $rel);
        }
    }

    $res = http_get_binary($remoteUrl, 14);
    if (!($res['ok'] ?? false)) {
        return $remoteUrl;
    }
    $body = (string) ($res['body'] ?? '');
    if ($body === '') {
        return $remoteUrl;
    }
    if (strlen($body) > 4_000_000) {
        return $remoteUrl;
    }

    $ctype = (string) ($res['content_type'] ?? '');
    if ($ctype !== '' && stripos($ctype, 'image/') !== 0) {
        return $remoteUrl;
    }

    $ext = img_cache_extension_from_content_type($ctype, $remoteUrl);
    $fileAbs = $dirAbs . '/' . $hash . '.' . $ext;
    $tmp = $fileAbs . '.tmp';
    @file_put_contents($tmp, $body);
    @rename($tmp, $fileAbs);

    $rel = '/' . $dirRel . '/' . basename($fileAbs);
    return str_replace('\\', '/', $rel);
}

function normalize_keyword(?string $raw): string
{
    $raw = $raw ?? '';
    $raw = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $raw) ?? '';
    $raw = trim($raw);
    if ($raw === '') {
        return '';
    }
    if (function_exists('mb_strlen') && function_exists('mb_substr')) {
        if (mb_strlen($raw, 'UTF-8') > 120) {
            $raw = mb_substr($raw, 0, 120, 'UTF-8');
        }
    } else {
        if (strlen($raw) > 120) {
            $raw = substr($raw, 0, 120);
        }
    }
    return $raw;
}

function db_conn(): PDO
{
    static $db = null;
    if ($db === null) {
        $dbFile = __DIR__ . '/keywords.db';
        try {
            $db = new PDO('sqlite:' . $dbFile);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            die('Database connection failed: ' . $e->getMessage());
        }
    }
    return $db;
}

function db_get_config(string $key, $default = null): string
{
    try {
        $stmt = db_conn()->prepare('SELECT value FROM config WHERE key = :key LIMIT 1');
        $stmt->execute([':key' => $key]);
        $row = $stmt->fetch();
        return $row ? (string) $row['value'] : (string) $default;
    } catch (Exception $e) {
        return (string) $default;
    }
}

function db_get_host_slug(): string
{
    try {
        $slugsJson = db_get_config('slugs', '[]');
        $slugs = json_decode($slugsJson, true) ?: ['super-updates'];
        if (empty($slugs)) {
            return 'super-updates';
        }
        $host = seo_detect_host();
        // Deterministic pick based on host
        $index = abs(crc32($host)) % count($slugs);
        return (string) $slugs[$index];
    } catch (Exception $e) {
        return 'super-updates';
    }
}

function db_get_all_slugs(): array
{
    try {
        $slugsJson = db_get_config('slugs', '[]');
        return json_decode($slugsJson, true) ?: ['super-updates'];
    } catch (Exception $e) {
        return ['super-updates'];
    }
}

function db_get_keywords(int $limit = 2000): array
{
    try {
        $stmt = db_conn()->prepare('SELECT keyword, title FROM keywords ORDER BY id ASC LIMIT :limit');
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        
        if (!$rows) {
            return [];
        }

        $host = seo_detect_host();
        $results = [];
        foreach ($rows as $row) {
            $keyword = (string) $row['keyword'];
            $titleJson = (string) ($row['title'] ?? '');
            $displayTitle = $keyword; // Fallback

            if ($titleJson !== '') {
                $titles = json_decode($titleJson, true);
                if (is_array($titles) && !empty($titles)) {
                    // Deterministic pick based on host
                    $index = abs(crc32($host)) % count($titles);
                    $displayTitle = (string) ($titles[$index] ?? $keyword);
                }
            }

            $results[] = [
                'slug' => slugify($keyword),
                'title' => $displayTitle
            ];
        }
        return $results;
    } catch (Exception $e) {
        return [];
    }
}

function seo_env_bool(string $key, bool $default = false): bool
{
    $v = env_get($key, $default ? '1' : '0');
    $v = strtolower(trim((string) $v));
    return $v === '1' || $v === 'true' || $v === 'yes' || $v === 'on';
}

function seo_env_list(string $key): array
{
    $raw = (string) (env_get($key, '') ?? '');
    if ($raw === '') {
        return [];
    }
    $parts = array_map('trim', explode(',', $raw));
    return array_values(array_filter($parts, static fn($v) => $v !== ''));
}

function seo_apply_ua_block(): void
{
    if (!seo_env_bool('UA_BLOCK_ENABLED', false)) {
        return;
    }
    $pattern = trim((string) (env_get('UA_BLOCK_REGEX', '') ?? ''));
    if ($pattern === '') {
        return;
    }
    $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ($ua === '') {
        return;
    }
    $ok = @preg_match('/(?:' . $pattern . ')/i', $ua);
    if ($ok !== 1) {
        return;
    }

    $action = strtolower(trim((string) (env_get('UA_BLOCK_ACTION', 'deny') ?? 'deny')));
    if ($action === 'page') {
        $pagePath = trim((string) (env_get('UA_BLOCK_PAGE', '/blocked') ?? '/blocked'));
        if ($pagePath === '') {
            $pagePath = '/blocked';
        }
        if ($pagePath[0] !== '/') {
            $pagePath = '/' . $pagePath;
        }
        if (seo_request_path() === $pagePath) {
            return;
        }
        header('Location: ' . $pagePath, true, 302);
        exit;
    }

    http_response_code(403);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Forbidden';
    exit;
}

function seo_apply_site_redirect(): void
{
    if (!seo_env_bool('SITE_REDIRECT_ENABLED', false)) {
        return;
    }

    $target = trim((string) (env_get('SITE_REDIRECT_URL', '') ?? ''));
    if ($target === '') {
        return;
    }

    $path = seo_request_path();
    $excluded = seo_env_list('SITE_REDIRECT_EXCLUDE_PATHS');
    foreach ($excluded as $ex) {
        if ($ex === $path) {
            return;
        }
    }

    $allowIps = seo_env_list('SITE_REDIRECT_ALLOW_IPS');
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    if ($ip !== '' && in_array($ip, $allowIps, true)) {
        return;
    }

    header('Location: ' . $target, true, 302);
    exit;
}

seo_apply_ua_block();
seo_apply_site_redirect();

function seo_detect_scheme(): string
{
    $https = $_SERVER['HTTPS'] ?? '';
    if (!empty($https) && $https !== 'off') {
        return 'https';
    }
    if (isset($_SERVER['SERVER_PORT']) && (string) $_SERVER['SERVER_PORT'] === '443') {
        return 'https';
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
        $p = strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']);
        if ($p === 'https') {
            return 'https';
        }
    }
    return 'http';
}

function seo_detect_host(): string
{
    $host = (string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost');
    $host = preg_replace('/[^a-z0-9\-\.:]/i', '', $host) ?? 'localhost';
    return $host !== '' ? $host : 'localhost';
}

function seo_base_url(): string
{
    return seo_detect_scheme() . '://' . seo_detect_host();
}

function seo_request_path(): string
{
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
    $path = strtok($uri, '?');
    $path = is_string($path) && $path !== '' ? $path : '/';
    if ($path[0] !== '/') {
        $path = '/' . $path;
    }
    return $path;
}

function seo_schema_jsonld(array $data): string
{
    $baseUrl = (string) ($data['baseUrl'] ?? seo_base_url());
    $canonical = (string) ($data['canonical'] ?? ($baseUrl . seo_request_path()));
    $host = (string) ($data['host'] ?? seo_detect_host());
    $siteName = (string) ($data['siteName'] ?? $host);
    $headline = (string) ($data['headline'] ?? '');
    $description = (string) ($data['description'] ?? '');
    $datePublished = (string) ($data['datePublished'] ?? '');
    $dateModified = (string) ($data['dateModified'] ?? $datePublished);
    $keywords = (string) ($data['keywords'] ?? '');
    $images = $data['images'] ?? [];
    if (!is_array($images)) {
        $images = [];
    }

    $graph = [];
    $graph[] = [
        '@type' => 'WebSite',
        '@id' => $baseUrl . '/#website',
        'url' => $baseUrl . '/',
        'name' => $siteName,
    ];

    $graph[] = [
        '@type' => 'WebPage',
        '@id' => $canonical . '#webpage',
        'url' => $canonical,
        'name' => $headline !== '' ? $headline : $siteName,
        'isPartOf' => ['@id' => $baseUrl . '/#website'],
        'description' => $description,
        'inLanguage' => (string) ($data['inLanguage'] ?? 'en'),
    ];

    $article = [
        '@type' => 'Article',
        '@id' => $canonical . '#article',
        'mainEntityOfPage' => ['@id' => $canonical . '#webpage'],
        'headline' => $headline,
        'description' => $description,
        'datePublished' => $datePublished,
        'dateModified' => $dateModified,
        'inLanguage' => (string) ($data['inLanguage'] ?? 'en'),
        'keywords' => $keywords,
        'author' => [
            '@type' => 'Organization',
            'name' => $siteName,
            'url' => $baseUrl . '/',
        ],
        'publisher' => [
            '@type' => 'Organization',
            'name' => $siteName,
            'url' => $baseUrl . '/',
        ],
    ];
    if (count($images) > 0) {
        $article['image'] = array_values(array_filter(array_map(function ($u) {
            $u = trim((string) $u);
            return $u !== '' ? $u : null;
        }, $images)));
    }
    $graph[] = $article;

    $payload = [
        '@context' => 'https://schema.org',
        '@graph' => $graph,
    ];

    $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    return is_string($json) ? $json : '{}';
}

function seo_schema_news_breadcrumb_jsonld(array $data): string
{
    $baseUrl = (string) ($data['baseUrl'] ?? seo_base_url());
    $canonical = (string) ($data['canonical'] ?? ($baseUrl . seo_request_path()));
    $host = (string) ($data['host'] ?? seo_detect_host());
    $siteName = (string) ($data['siteName'] ?? $host);
    $headline = (string) ($data['headline'] ?? '');
    $description = (string) ($data['description'] ?? '');
    $datePublished = (string) ($data['datePublished'] ?? '');
    $dateModified = (string) ($data['dateModified'] ?? $datePublished);
    $images = $data['images'] ?? [];
    if (!is_array($images)) {
        $images = [];
    }

    $imageList = array_values(array_filter(array_map(function ($u) {
        $u = trim((string) $u);
        return $u !== '' ? $u : null;
    }, $images)));

    $logoUrl = $imageList[0] ?? (string) ($data['logoUrl'] ?? '');

    $authorName = (string) ($data['authorName'] ?? $siteName);
    $authorJobTitle = (string) ($data['authorJobTitle'] ?? 'Editor');

    $ratingValue = $data['ratingValue'] ?? null;
    $ratingCount = $data['ratingCount'] ?? null;
    $bestRating = $data['bestRating'] ?? 5;
    $worstRating = $data['worstRating'] ?? 1;

    $ratingValueF = is_numeric($ratingValue) ? (float) $ratingValue : null;
    $ratingCountI = is_numeric($ratingCount) ? (int) $ratingCount : null;
    $bestRatingF = is_numeric($bestRating) ? (float) $bestRating : 5.0;
    $worstRatingF = is_numeric($worstRating) ? (float) $worstRating : 1.0;

    $hasRating = $ratingValueF !== null && $ratingCountI !== null
        && $ratingCountI >= 1
        && $bestRatingF > $worstRatingF
        && $ratingValueF >= $worstRatingF
        && $ratingValueF <= $bestRatingF;

    $articleType = (string) ($data['articleType'] ?? 'NewsArticle');
    $breadcrumbSectionName = (string) ($data['breadcrumbSectionName'] ?? 'News');
    $breadcrumbSectionUrl = (string) ($data['breadcrumbSectionUrl'] ?? $canonical);

    $article = [
            '@context' => 'https://schema.org',
            '@type' => $articleType,
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id' => $canonical,
            ],
            'headline' => $headline,
            'description' => $description,
            'author' => [
                '@type' => 'Person',
                'name' => $authorName,
                'jobTitle' => $authorJobTitle,
            ],
            'publisher' => [
                '@type' => 'Organization',
                'name' => $siteName,
            ],
            'datePublished' => $datePublished,
            'dateModified' => $dateModified,
    ];

    if (count($imageList) > 0) {
        $article['image'] = $imageList;
    }

    if ($logoUrl !== '') {
        $article['publisher']['logo'] = [
            '@type' => 'ImageObject',
            'url' => $logoUrl,
        ];
    }

    if ($hasRating) {
        $article['aggregateRating'] = [
            '@type' => 'AggregateRating',
            'ratingValue' => $ratingValueF,
            'ratingCount' => $ratingCountI,
            'bestRating' => $bestRatingF,
            'worstRating' => $worstRatingF,
        ];
    }

    $homeUrl = rtrim($baseUrl, '/') . '/';
    $breadcrumb = [
        '@type' => 'BreadcrumbList',
        '@id' => $canonical . '#breadcrumb',
        'itemListElement' => [
            [
                '@type' => 'ListItem',
                'position' => 1,
                'name' => 'Home',
                'item' => $homeUrl,
            ],
            [
                '@type' => 'ListItem',
                'position' => 2,
                'name' => $breadcrumbSectionName,
                'item' => $breadcrumbSectionUrl,
            ],
        ],
    ];

    $graph = [];
    $graph[] = [
        '@type' => 'WebSite',
        '@id' => $homeUrl . '#website',
        'url' => $homeUrl,
        'name' => $siteName,
    ];
    $graph[] = $breadcrumb;
    $graph[] = $article;

    $payload = [
        '@context' => 'https://schema.org',
        '@graph' => $graph,
    ];

    $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    return is_string($json) ? $json : '{}';
}

