<?php

declare(strict_types=1);

require_once __DIR__ . '/schema.php';

$https = (string) ($_SERVER['HTTPS'] ?? '');
$scheme = (!empty($https) && $https !== 'off') ? 'https' : 'http';
if (isset($_SERVER['SERVER_PORT']) && (string) $_SERVER['SERVER_PORT'] === '443') {
    $scheme = 'https';
}
if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') {
    $scheme = 'https';
}

$host = (string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost');
$host = preg_replace('/[^a-z0-9\-\.:]/i', '', $host) ?? 'localhost';
$host = $host !== '' ? $host : 'localhost';

$siteName = function_exists('env_get') ? (env_get('SITE_NAME', $host) ?? $host) : $host;
$canonical = $scheme . '://' . $host . '/blocked';

http_response_code(403);
header('Content-Type: text/html; charset=UTF-8');

?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= e($siteName) ?> - Access restricted</title>
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="shortcut icon" href="/favicon.svg">
  <meta name="robots" content="noindex,nofollow">
  <link rel="canonical" href="<?= e($canonical) ?>">
  <style>
    :root{--bg:#0f1218;--text:#f2f4f7;--muted:#9aa7b6;--border:rgba(255,255,255,.08);--accent:#ff3b3b}
    *{box-sizing:border-box}
    body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:linear-gradient(180deg,var(--bg),#0b0e14);color:var(--text);line-height:1.6}
    a{color:inherit}
    .wrap{max-width:760px;margin:0 auto;padding:32px 20px}
    .card{border:1px solid var(--border);border-radius:16px;background:rgba(255,255,255,.02);padding:18px}
    .badge{color:var(--accent);font-weight:800;text-transform:uppercase;letter-spacing:.08em;font-size:.78rem}
    h1{margin:10px 0 8px;font-size:1.7rem}
    .muted{color:var(--muted)}
    code{background:rgba(255,255,255,.06);padding:2px 6px;border-radius:8px}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <div class="badge">403</div>
      <h1>Access restricted</h1>
      <p class="muted">Your client is not allowed to access this website.</p>
      <p class="muted">If you believe this is an error, contact us at <a href="/contact">/contact</a>.</p>
    </div>
  </div>
</body>
</html>
