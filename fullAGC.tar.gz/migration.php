<?php
/**
 * Migration Script: Migrate Keywords (txt) and Config (env/code) to SQLite
 */

$dbFile = __DIR__ . '/keywords.db';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Function for helper logic
function env_get_simple(string $key, $default = null): ?string {
    $val = getenv($key);
    return $val !== false ? $val : $default;
}

try {
    if (is_file($dbFile)) {
        echo "Removing existing database...\n";
        unlink($dbFile);
    }

    $db = new PDO('sqlite:' . $dbFile);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Creating tables...\n";
    // id, keyword, title (json array)
    $db->exec('CREATE TABLE keywords (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        keyword TEXT NOT NULL,
        title TEXT NOT NULL
    )');

    // id, value
    $db->exec('CREATE TABLE config (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )');

    echo "Loading configuration...\n";
    // Fetch from .env if possible
    $siteName = 'AGC James';
    $envFile = __DIR__ . '/.env';
    if (is_file($envFile)) {
        $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $l) {
            if (strpos($l, 'SITE_NAME=') === 0) {
                $siteName = trim(substr($l, 10));
                break;
            }
        }
    }

    $config = [
        'site_name' => $siteName !== '' ? $siteName : 'AGC James',
        'meta_description' => 'Neutral homepage with featured, popular, and latest posts.',
        'index_title' => $siteName !== '' ? $siteName : 'AGC James',
        'slugs' => json_encode(["super-updates", "featured", "trends", "report"])
    ];

    $stmt = $db->prepare('INSERT INTO config (key, value) VALUES (:key, :value)');
    foreach ($config as $k => $v) {
        $stmt->execute([':key' => $k, ':value' => $v]);
    }

    echo "Migrating keywords...\n";
    $keywordsFile = __DIR__ . '/sitemap_keywords.txt';
    $count = 0;
    if (is_file($keywordsFile)) {
        $lines = file($keywordsFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (is_array($lines)) {
            $db->beginTransaction();
            $stmt = $db->prepare('INSERT INTO keywords (keyword, title) VALUES (:keyword, :title)');
            foreach ($lines as $line) {
                $kw = trim((string) $line);
                if ($kw !== '') {
                    $stmt->execute([':keyword' => $kw, ':title' => json_encode([$kw])]);
                    $count++;
                }
            }
            $db->commit();
        }
    }

    echo "Migration completed successfully!\n";
    echo "Total keywords migrated: $count\n";

} catch (Exception $e) {
    echo "FATAL ERROR during migration: " . $e->getMessage() . "\n";
}
