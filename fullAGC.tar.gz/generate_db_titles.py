import sys
import os
import sqlite3
import json
import asyncio
from pathlib import Path
from time import time

# Add the library from windsurf-project to sys.path
WINDSURF_PATH = Path(r"c:\Users\Jagger\CascadeProjects\windsurf-project")
LIB_PATH = WINDSURF_PATH / "lib" / "perplexity-ai"
sys.path.append(str(LIB_PATH))

try:
    import perplexity_async
except ImportError as e:
    print(f"❌ Error importing perplexity_async library from {LIB_PATH}: {e}")
    sys.exit(1)

# Database path in agcjames
DB_PATH = Path(__file__).parent / "keywords.db"

SEO_PROMPT_TEMPLATE = """You are a SEO expert and your job is to analyze the searched keyword result for the intent and hooks.

Output 5 SEO titles based on that without any placeholder. The output must be a JSON formatted block code
{{
      "keyword": "{keyword}",
      "category": "",
      "search_intent": "",
      "popular_hooks_found": [],
      "titles": []
    }}"""

# Configuration
BATCH_SIZE = 5
SLEEP_BETWEEN_BATCHES = 3 # Seconds

async def generate_seo_titles_for_keyword(client, keyword):
    """
    Uses the Perplexity library to generate SEO titles for a keyword.
    Returns a parsed JSON object or None on failure.
    """
    prompt = SEO_PROMPT_TEMPLATE.format(keyword=keyword)

    try:
        response = await client.search(prompt, mode="auto")

        if not response:
            return None

        raw_answer = response.get('answer', '')
        if not raw_answer:
            return None

        # Extract JSON block from the answer
        json_str = raw_answer
        if "```json" in raw_answer:
            start = raw_answer.index("```json") + len("```json")
            end = raw_answer.index("```", start)
            json_str = raw_answer[start:end].strip()
        elif "```" in raw_answer:
            start = raw_answer.index("```") + len("```")
            end = raw_answer.index("```", start)
            json_str = raw_answer[start:end].strip()
        else:
            brace_start = raw_answer.find('{')
            brace_end = raw_answer.rfind('}')
            if brace_start != -1 and brace_end != -1:
                json_str = raw_answer[brace_start:brace_end + 1]

        result = json.loads(json_str)
        return {"keyword": keyword, "result": result}

    except Exception as e:
        print(f"❌ Generation failed for '{keyword}': {str(e)}")
        return None

async def process_all_single_title_records():
    """Loops through all records with json_array_length(title) = 1 in batches of BATCH_SIZE."""
    if not DB_PATH.exists():
        print(f"❌ Database not found at: {DB_PATH}")
        return

    # Initialize the Perplexity async client outside the loop
    try:
        client = await perplexity_async.Client()
    except Exception as e:
        print(f"❌ Failed to initialize client: {e}")
        return

    while True:
        # Re-connect/re-query each time to pick up new state
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        try:
            # Query for the next batch of records where title array length is 1
            # Note: We use json_array_length() which requires title to be a JSON array string like '["word"]'
            cursor.execute("SELECT id, keyword FROM keywords WHERE json_array_length(title) = 1 ORDER BY id ASC LIMIT ?", (BATCH_SIZE,))
            rows = cursor.fetchall()
            
            if not rows:
                print("🏁 No more single-title records found. Processing complete.")
                break

            print(f"\n📦 Starting new batch of {len(rows)} keywords...")
            start_time = time()
            
            # Create and execute tasks concurrently for this batch
            tasks = [generate_seo_titles_for_keyword(client, keyword) for _, keyword in rows]
            batch_results = await asyncio.gather(*tasks)
            
            elapsed = time() - start_time
            print(f"✅ Batch processed in {elapsed:.2f}s")

            # Update database
            updated_count = 0
            for (row_id, keyword), result_obj in zip(rows, batch_results):
                if result_obj and result_obj['result']:
                    # Extract only the 'titles' array
                    titles_list = result_obj['result'].get('titles', [])
                    if titles_list:
                        json_result = json.dumps(titles_list, indent=2)
                        cursor.execute("UPDATE keywords SET title = ? WHERE id = ?", (json_result, row_id))
                        updated_count += 1
                        print(f"📝 UPDATED: [ID {row_id}] {keyword}")
                else:
                    print(f"⚠️  FAILED: [ID {row_id}] {keyword}")

            conn.commit()
            print(f"💾 Saved {updated_count} updates to database.")

            # Cooldown to avoid spamming
            print(f"⏳ Waiting {SLEEP_BETWEEN_BATCHES}s before next batch...")
            await asyncio.sleep(SLEEP_BETWEEN_BATCHES)

        except Exception as e:
            print(f"❌ Error during batch: {e}")
            break
        finally:
            conn.close()

if __name__ == "__main__":
    print("🚀 Starting Automated Keyword Multi-Batch Processor")
    print(f"⚙️  Batch Size: {BATCH_SIZE} | Cooldown: {SLEEP_BETWEEN_BATCHES}s")
    asyncio.run(process_all_single_title_records())
    print("\n🔚 Batch Processor shut down.")
