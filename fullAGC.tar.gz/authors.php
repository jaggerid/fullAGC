<?php

declare(strict_types=1);

require_once __DIR__ . '/schema.php';


$authorsJson = __DIR__ . '/authors.json';
$authors = [];
if (is_file($authorsJson)) {
    $raw = file_get_contents($authorsJson);
    $authors = json_decode($raw, true) ?: [];
}

$slug = $_GET['slug'] ?? '';
$currentAuthor = null;
if ($slug !== '') {
    foreach ($authors as $auth) {
        if (($auth['slug'] ?? '') === $slug) {
            $currentAuthor = $auth;
            break;
        }
    }
}

// REDIRECT IF NO AUTHOR SLUG (REMOVE LIST VIEW)
if (!$currentAuthor) {
    header('Location: /', true, 301);
    exit;
}

$scheme = seo_detect_scheme();
$host = seo_detect_host();
$base = $scheme . '://' . $host;
$canonical = $base . '/authors/' . $currentAuthor['slug'];

$siteName = db_get_config('site_name', $host);
$currentSlug = db_get_host_slug();

$pageTitle = $currentAuthor['name'] . ' - ' . $siteName;
$metaDescription = $currentAuthor['bio'] ?? 'Author profile for ' . $currentAuthor['name'];

// Recent Posts Logic
$recentPosts = [];
$keywords = db_get_keywords(1000);
if (!empty($keywords)) {
    // Pick deterministic random posts based on author slug
    mt_srand(crc32($currentAuthor['slug']));
    shuffle($keywords);
    $recentPosts = array_slice($keywords, 0, 8);
    mt_srand(); // reset
}

// Schema Logic
$graph = [
    [
        '@type' => 'WebSite',
        '@id' => $base . '/#website',
        'url' => $base . '/',
        'name' => $siteName,
    ],
    [
        '@type' => 'WebPage',
        '@id' => $canonical . '#webpage',
        'url' => $canonical,
        'name' => $pageTitle,
        'isPartOf' => ['@id' => $base . '/#website'],
        'description' => $metaDescription,
    ],
    [
        '@type' => 'Person',
        'name' => $currentAuthor['name'],
        'jobTitle' => $currentAuthor['role'],
        'description' => $currentAuthor['bio'],
        'url' => $canonical
    ]
];

$breadcrumb = [
    '@type' => 'BreadcrumbList',
    '@id' => $canonical . '#breadcrumb',
    'itemListElement' => [
        [
            '@type' => 'ListItem',
            'position' => 1,
            'name' => 'Home',
            'item' => $base . '/',
        ],
        [
            '@type' => 'ListItem',
            'position' => 2,
            'name' => $currentAuthor['name'],
            'item' => $canonical,
        ]
    ]
];

$graph[] = $breadcrumb;

$schema = json_encode(['@context' => 'https://schema.org', '@graph' => $graph], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

header('Content-Type: text/html; charset=UTF-8');

?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= e($pageTitle) ?></title>
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="shortcut icon" href="/favicon.svg">
  <meta name="description" content="<?= e($metaDescription) ?>">
  <link rel="canonical" href="<?= e($canonical) ?>">
  <meta name="robots" content="index,follow">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="<?= e($siteName) ?>">
  <meta property="og:title" content="<?= e($pageTitle) ?>">
  <meta property="og:description" content="<?= e($metaDescription) ?>">
  <meta property="og:url" content="<?= e($canonical) ?>">
  <meta name="twitter:card" content="summary">
  <meta name="twitter:title" content="<?= e($pageTitle) ?>">
  <meta name="twitter:description" content="<?= e($metaDescription) ?>">
  <script type="application/ld+json"><?= $schema !== false ? $schema : '{}' ?></script>
  <style>
    :root{--bg:#0f1218;--text:#f2f4f7;--muted:#9aa7b6;--border:rgba(255,255,255,.08);--accent:#ff3b3b}
    *{box-sizing:border-box}
    body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:linear-gradient(180deg,var(--bg),#0b0e14);color:var(--text);line-height:1.65}
    a{color:inherit;text-decoration:none}
    a:hover{text-decoration:underline}
    .container{max-width:980px;margin:0 auto;padding:26px 22px}
    .top{display:flex;gap:14px;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border);padding-bottom:14px}
    .brand{font-weight:900;letter-spacing:.08em;text-decoration:none}
    .nav{display:flex;gap:14px;flex-wrap:wrap}
    .nav a{text-decoration:none;color:var(--muted)}
    .nav a:hover{color:var(--text)}
    h1{margin:20px 0 10px;font-size:2rem;letter-spacing:-.01em}
    h2{margin:0 0 6px;font-size:1.1rem}
    .muted{color:var(--muted)}
    .badge{color:var(--accent);font-weight:800;text-transform:uppercase;letter-spacing:.08em;font-size:.78rem}
    .card{border:1px solid var(--border);border-radius:16px;background:rgba(255,255,255,.02);padding:16px 16px;margin-bottom:14px}
    .role{color:var(--accent);font-weight:800;text-transform:uppercase;letter-spacing:.08em;font-size:.78rem}
    .post-list{margin:20px 0;padding:0;list-style:none}
    .post-list li{margin-bottom:8px}
    .post-list a{color:var(--text);font-weight:600}
    .footer{border-top:1px solid var(--border);margin-top:22px;padding-top:14px;color:var(--muted);font-size:.95rem}
  </style>
</head>
<body>
  <div class="container">
    <div class="top">
      <a class="brand" href="/"><?= e($siteName) ?></a>
      <nav class="nav" aria-label="Secondary">
        <a href="/">Home</a>
        <a href="/dmca">DMCA</a>
        <a href="/contact">Contact</a>
        <a href="/privacy-policy">Privacy Policy</a>
        <a href="/copyright">Copyright</a>
      </nav>
    </div>

    <div class="badge">/ AUTHOR PROFILE</div>
    <h1><?= e($currentAuthor['name']) ?></h1>
    <div class="role"><?= e($currentAuthor['role']) ?></div>
    
    <div class="card" style="margin-top:14px">
        <h2>About The Author</h2>
        <p><?= e($currentAuthor['bio']) ?></p>
        
        <?php if (!empty($currentAuthor['past_work'])): ?>
            <h3>Past Work</h3>
            <p class="muted"><?= e($currentAuthor['past_work']) ?></p>
        <?php endif; ?>
    </div>

    <?php if (!empty($recentPosts)): ?>
        <h2>Recent Publications</h2>
        <ul class="post-list">
            <?php foreach ($recentPosts as $post): ?>
                <li><a href="/<?= e($currentSlug) ?>/<?= e((string) $post['slug']) ?>"><?= e($post['title']) ?></a></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <div class="footer">© <?= e((string) date('Y')) ?> <?= e($siteName) ?> • <a href="/sitemap.xml">Sitemap</a></div>
  </div>
</body>
</html>
