<?php

declare(strict_types=1);

require_once __DIR__ . '/schema.php';

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$scheme = seo_detect_scheme();
$host = seo_detect_host();
$base = $scheme . '://' . $host;
$canonical = $base . '/authors';

$siteName = env_get('SITE_NAME', $host) ?? $host;
$pageTitle = 'Authors - ' . $siteName;
$metaDescription = 'Editorial and authors information.';

$schema = json_encode([
    '@context' => 'https://schema.org',
    '@graph' => [
        [
            '@type' => 'WebSite',
            '@id' => $base . '/#website',
            'url' => $base . '/',
            'name' => $siteName,
        ],
        [
            '@type' => 'WebPage',
            '@id' => $canonical . '#webpage',
            'url' => $canonical,
            'name' => $pageTitle,
            'isPartOf' => ['@id' => $base . '/#website'],
            'description' => $metaDescription,
        ],
        [
            '@type' => 'BreadcrumbList',
            '@id' => $canonical . '#breadcrumb',
            'itemListElement' => [
                [
                    '@type' => 'ListItem',
                    'position' => 1,
                    'name' => 'Home',
                    'item' => $base . '/',
                ],
                [
                    '@type' => 'ListItem',
                    'position' => 2,
                    'name' => 'Authors',
                    'item' => $canonical,
                ],
            ],
        ],
    ],
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

$defaultAuthors = [
    [
        'name' => $siteName,
        'role' => 'Editor',
        'bio' => 'Site editorial account for published content.',
    ],
];

header('Content-Type: text/html; charset=UTF-8');

?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= e($pageTitle) ?></title>
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="shortcut icon" href="/favicon.svg">
  <meta name="description" content="<?= e($metaDescription) ?>">
  <link rel="canonical" href="<?= e($canonical) ?>">
  <meta name="robots" content="index,follow">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="<?= e($siteName) ?>">
  <meta property="og:title" content="<?= e($pageTitle) ?>">
  <meta property="og:description" content="<?= e($metaDescription) ?>">
  <meta property="og:url" content="<?= e($canonical) ?>">
  <meta name="twitter:card" content="summary">
  <meta name="twitter:title" content="<?= e($pageTitle) ?>">
  <meta name="twitter:description" content="<?= e($metaDescription) ?>">
  <script type="application/ld+json"><?= $schema !== false ? $schema : '{}' ?></script>
  <style>
    :root{--bg:#0f1218;--text:#f2f4f7;--muted:#9aa7b6;--border:rgba(255,255,255,.08);--accent:#ff3b3b}
    *{box-sizing:border-box}
    body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:linear-gradient(180deg,var(--bg),#0b0e14);color:var(--text);line-height:1.65}
    a{color:inherit}
    .container{max-width:980px;margin:0 auto;padding:26px 22px}
    .top{display:flex;gap:14px;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border);padding-bottom:14px}
    .brand{font-weight:900;letter-spacing:.08em;text-decoration:none}
    .nav{display:flex;gap:14px;flex-wrap:wrap}
    .nav a{text-decoration:none;color:var(--muted)}
    .nav a:hover{color:var(--text)}
    h1{margin:20px 0 10px;font-size:2rem;letter-spacing:-.01em}
    h2{margin:0 0 6px;font-size:1.1rem}
    .muted{color:var(--muted)}
    .badge{color:var(--accent);font-weight:800;text-transform:uppercase;letter-spacing:.08em;font-size:.78rem}
    .grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-top:14px}
    @media (max-width:760px){.grid{grid-template-columns:1fr}}
    .card{border:1px solid var(--border);border-radius:16px;background:rgba(255,255,255,.02);padding:16px 16px}
    .role{color:var(--accent);font-weight:800;text-transform:uppercase;letter-spacing:.08em;font-size:.78rem}
    .footer{border-top:1px solid var(--border);margin-top:22px;padding-top:14px;color:var(--muted);font-size:.95rem}
  </style>
</head>
<body>
  <div class="container">
    <div class="top">
      <a class="brand" href="/"><?= e($siteName) ?></a>
      <nav class="nav" aria-label="Secondary">
        <a href="/dmca">DMCA</a>
        <a href="/contact">Contact</a>
        <a href="/privacy-policy">Privacy Policy</a>
        <a href="/copyright">Copyright</a>
        <a href="/authors">Authors</a>
      </nav>
    </div>

    <div class="badge">/ AUTHORS</div>
    <h1>Authors</h1>
    <p class="muted">Information about editorial accounts and contributors.</p>

    <div class="grid">
      <?php foreach ($defaultAuthors as $a): ?>
        <div class="card">
          <div class="role"><?= e($a['role']) ?></div>
          <h2><?= e($a['name']) ?></h2>
          <div class="muted"><?= e($a['bio']) ?></div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="footer">© <?= e((string) date('Y')) ?> <?= e($siteName) ?> • <a href="/sitemap.xml">Sitemap</a></div>
  </div>
</body>
</html>
