const fs = require('fs');
const path = require('path');

// --- .ENV LOADER ---
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
    const lines = fs.readFileSync(envPath, 'utf8').split('\n');
    lines.forEach(line => {
        const parts = line.split('=');
        if (parts.length >= 2) {
            const key = parts[0].trim();
            const val = parts.slice(1).join('=').trim();
            if (key) process.env[key] = val;
        }
    });
}

const keyword = process.argv[2];
if (!keyword) {
    console.error("Error: Provide a keyword.");
    process.exit(1);
}

const apiKey = process.env.GROQ_API_KEY;

async function generateSearchModelTitles(kw) {
    const url = "https://api.groq.com/openai/v1/chat/completions";

    // PROMPT OPTIMIZATION: Be very direct.
    const prompt = `Search for: "${kw}". 
    Analyze the top 3 results for intent and hooks. 
    Output 3 SEO titles (no placeholders).
    
    JSON: {
      "keyword": "${kw}",
      "search_intent": "",
      "popular_hooks_found": [],
      "titles": []
    }`;

    try {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${apiKey}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                model: "groq/compound-mini",
                messages: [
                    {
                        role: "system",
                        // Optimized: Short & focused
                        content: "You are an SEO specialist. Use web_search for every keyword provided. Always respond in valid JSON."
                    },
                    {
                        role: "user",
                        content: prompt
                    }
                ],
                compound_custom: {
                    tools: {
                        enabled_tools: [
                            "web_search" // REMOVED visit_website to save ~70% of tokens
                        ]
                    }
                },
                response_format: { type: "json_object" },
                temperature: 0.2, // Lower temp = more predictable token usage
            })
        });

        const data = await response.json();

        if (data.choices && data.choices[0]) {
            console.log(data.choices[0].message.content);

            // To monitor your cost, log the usage:
            if (data.usage) {
                console.log(`\nTokens used: ${data.usage.total_tokens}`);
            }
        } else {
            console.error("API Error:", data.error?.message || "Unknown error");
        }
    } catch (error) {
        console.error("Request failed:", error.message);
    }
}

generateSearchModelTitles(keyword);