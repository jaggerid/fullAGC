<?php

declare(strict_types=1);

require_once __DIR__ . '/schema.php';


// --- DATA CACHE FUNCTIONS ---

function data_cache_enabled(): bool
{
    $v = env_get('DATA_CACHE_ENABLED', '1');
    $v = strtolower(trim((string) $v));
    return $v === '1' || $v === 'true' || $v === 'yes' || $v === 'on';
}

function data_cache_ttl(): int
{
    $v = env_get('DATA_CACHE_TTL', '604800');
    $n = is_numeric($v) ? (int) $v : 604800;
    return max(60, $n);
}

function data_cache_dir(): string
{
    $v = trim((string) (env_get('DATA_CACHE_DIR', 'cache/data') ?? 'cache/data'));
    return $v !== '' ? $v : 'cache/data';
}

function data_cache_file(string $slug): string
{
    $slug = trim($slug);
    if ($slug === '') {
        $slug = 'page-' . substr(sha1((string) microtime(true)), 0, 12);
    }
    $dir = rtrim(__DIR__ . '/' . trim(data_cache_dir(), '/\\'), '/\\');
    return $dir . '/' . $slug . '.txt';
}

function data_cache_read(string $cacheFile, int $ttlSeconds): ?array
{
    if (!is_file($cacheFile)) {
        return null;
    }
    $age = time() - (int) filemtime($cacheFile);
    if ($age < 0 || $age > $ttlSeconds) {
        return null;
    }

    $text = @file_get_contents($cacheFile);
    if (!$text)
        return null;

    $lines = explode("\n", trim($text));
    if (count($lines) < 2) {
        return null;
    }

    $published = trim(array_shift($lines));
    $bingOk = (int) trim(array_shift($lines)) === 1;
    $images = [];

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line !== '') {
            $images[] = $line;
        }
    }

    return [
        'published' => $published,
        'bing' => [
            'ok' => $bingOk,
            'status' => 200,
            'error' => '',
            'images' => $images
        ]
    ];
}

function data_cache_write(string $cacheFile, array $data): void
{
    $dir = dirname($cacheFile);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }

    $published = $data['published'] ?? '';
    $bingOk = ($data['bing']['ok'] ?? false) ? '1' : '0';
    $images = $data['bing']['images'] ?? [];

    $lines = [$published, $bingOk];
    foreach ($images as $img) {
        $lines[] = trim((string) $img);
    }

    $tmp = $cacheFile . '.tmp';
    @file_put_contents($tmp, implode("\n", $lines));
    @rename($tmp, $cacheFile);
}

// --- END CACHE FUNCTIONS ---

// --- KEYWORD SUGGESTION FUNCTIONS ---

function fetch_google_suggestions(string $keyword, ?string $proxy = null): array
{
    $url = 'https://suggestqueries.google.com/complete/search?client=firefox&gl=US&hl=en&q=' . rawurlencode($keyword);
    $res = http_get_with_headers($url, [], 10, $proxy);
    if (!$res['ok'] || empty($res['body'])) {
        return [];
    }
    $data = @json_decode($res['body'], true);
    if (is_array($data) && isset($data[1]) && is_array($data[1])) {
        return $data[1];
    }
    return [];
}

function append_new_keywords(array $newKeywords): void
{
    if (count($newKeywords) === 0) {
        return;
    }
    $file = __DIR__ . '/sitemap_keywords.txt';
    $existing = [];
    if (is_file($file)) {
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (is_array($lines)) {
            $existing = $lines;
        }
    }

    $all = array_merge($existing, $newKeywords);
    $unique = [];
    $seen = [];
    foreach ($all as $k) {
        $k = trim((string) $k);
        if ($k === '') {
            continue;
        }
        $low = strtolower($k);
        if (!isset($seen[$low])) {
            $seen[$low] = true;
            $unique[] = $k;
        }
    }

    @file_put_contents($file, implode("\n", $unique) . "\n");
}

// --- END KEYWORD SUGGESTION FUNCTIONS ---

function random_phrase(): string
{
    $phrases = [
        'Trending Now',
        'Popular Today',
        'Viral Hits',
        'Most Read',
        'Most Shared',
        'People Are Talking About',
        'Rising Stars',
        'Top Trending',
        'Buzzing Right Now',
        'Gaining Traction',
        'On the Rise',
        'Community Favorites'
    ];
    return $phrases[array_rand($phrases)];
}

function random_sentence(): string
{
    $sentences = [
        'Dont miss out on the trend everyone is talking about.',
        'Catch up fast on the buzz you missed today.',
        'Stay in the loop with these trending highlights.',
        'Get instant access to the hottest topics before they fade.',
        'Unlock the trends you need to stay relevant.',
        'Be the first to know what is trending tomorrow.',
        'Stay ahead of the curve with these rising trends.',
        'Dont get left behind—see what is popular now.',
        'Catch the trending wave before it crashes.',
        'Stay plugged into the internets biggest moments.',
        'Keep your finger on the pulse of what is hot.',
        'Ensure you never miss a viral moment again.',
        'Get your daily dose of the most popular updates.',
        'Stay current with the top trending summaries.',
        'Unlock a quick overview of todays massive trends.',
        'Dont sleep on these incredibly popular stories.',
        'Jump into the trending topics before they change.',
        'Stay sharp with the latest buzz and highlights.',
        'Feed your curiosity with what is trending right now.',
        'Get the ultimate breakdown of todays top trends.'
    ];
    return $sentences[array_rand($sentences)];
}

function count_words(string $text): int
{
    $text = trim($text);
    if ($text === '') {
        return 0;
    }
    $parts = preg_split('/\s+/u', $text) ?: [];
    $n = 0;
    foreach ($parts as $p) {
        if (trim((string) $p) !== '') {
            $n++;
        }
    }
    return $n;
}

function truncate_to_words(string $text, int $maxWords): string
{
    $maxWords = max(1, $maxWords);
    $text = trim((string) preg_replace('/\s+/u', ' ', $text));
    if ($text === '') {
        return '';
    }
    $parts = preg_split('/\s+/u', $text) ?: [];
    if (count($parts) <= $maxWords) {
        return $text;
    }
    $parts = array_slice($parts, 0, $maxWords);
    return trim(implode(' ', $parts));
}

function build_random_text(string $keyword, int $maxWords = 500): string
{
    static $templates = null;
    if ($templates === null) {
        $templates = [];
        $dir = __DIR__ . '/templates/random_text';
        $files = glob($dir . '/*.txt');
        if (is_array($files)) {
            sort($files);
            foreach ($files as $file) {
                if (!is_file($file)) {
                    continue;
                }
                $lines = file($file, FILE_IGNORE_NEW_LINES);
                if (!is_array($lines)) {
                    continue;
                }
                foreach ($lines as $line) {
                    $line = trim((string) $line);
                    if ($line === '' || (isset($line[0]) && $line[0] === '#')) {
                        continue;
                    }
                    $line = truncate_to_words($line, 500);
                    if (count_words($line) < 3) {
                        continue;
                    }
                    $templates[] = $line;
                    if (count($templates) >= 2000) {
                        break 2;
                    }
                }
            }
        }
    }

    if (!is_array($templates) || count($templates) === 0) {
        $templates = [
            '{keyword}: {phrase} Get the full details now.',
            'Instant access to {keyword}: {phrase}. No signup required.',
            'Unlock the full guide: {keyword} {phrase}. Start reading.',
        ];
    }

    $maxWords = max(50, $maxWords);

    $sentences = [];
    $seen = [];
    $words = 0;

    for ($i = 0; $i < 3000; $i++) {
        if ($words >= $maxWords) {
            break;
        }

        $tpl = $templates[array_rand($templates)];
        $phrase = random_phrase();
        if (strpos($tpl, '%s') !== false) {
            $s = sprintf($tpl, $keyword, $phrase);
        } else {
            $s = str_replace(['{keyword}', '{phrase}'], [$keyword, $phrase], $tpl);
        }
        $s = trim((string) preg_replace('/\s+/u', ' ', $s));
        if ($s === '') {
            continue;
        }
        if (!preg_match('/[\.!\?]$/', $s)) {
            $s .= '.';
        }

        $key = strtolower((string) preg_replace('/[^a-z0-9]+/i', ' ', $s));
        $key = trim((string) preg_replace('/\s+/u', ' ', $key));
        if ($key === '' || isset($seen[$key])) {
            continue;
        }

        $w = count_words($s);
        if ($w <= 0) {
            continue;
        }
        if (($words + $w) > $maxWords) {
            $remain = $maxWords - $words;
            if ($remain <= 0) {
                break;
            }
            $s = truncate_to_words($s, $remain);
            $w = count_words($s);
            if ($w <= 0) {
                break;
            }
        }

        $seen[$key] = true;
        $sentences[] = $s;
        $words += $w;
    }

    if (count($sentences) === 0) {
        return $keyword . ': ' . random_phrase() . '.';
    }
    return implode(' ', $sentences);
}

function load_keywords_file(string $filePath, int $limit = 600): array
{
    if (!is_file($filePath)) {
        return [];
    }
    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!is_array($lines)) {
        return [];
    }
    $out = [];
    $seen = [];
    foreach ($lines as $line) {
        $line = trim((string) $line);
        if ($line === '') {
            continue;
        }
        $key = strtolower($line);
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $out[] = $line;
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

function build_related_links(string $keyword, int $limit = 6): array
{
    $items = [];
    $seen = [];

    $all = load_keywords_file(__DIR__ . '/sitemap_keywords.txt', 1200);
    $kwLower = strtolower(trim($keyword));
    $pool = [];
    foreach ($all as $k) {
        $k = trim((string) $k);
        if ($k === '') {
            continue;
        }
        if (strtolower($k) === $kwLower) {
            continue;
        }
        $pool[] = $k;
    }

    if (count($pool) > 0) {
        shuffle($pool);
        foreach ($pool as $p) {
            if (count($items) >= $limit) {
                break;
            }
            $slug = slugify($p);
            if ($slug === '' || isset($seen[$slug])) {
                continue;
            }
            $seen[$slug] = true;
            $items[] = [
                'label' => $p,
                'q' => $slug,
            ];
        }
    }

    if (count($items) === 0) {
        $fallbacks = [
            $keyword . ' ' . random_phrase(),
            random_phrase() . ' ' . $keyword,
            'guide ' . $keyword,
            'summary ' . $keyword,
            'latest ' . $keyword,
        ];
        foreach ($fallbacks as $f) {
            if (count($items) >= $limit) {
                break;
            }
            $slug = slugify($f);
            if ($slug === '' || isset($seen[$slug])) {
                continue;
            }
            $seen[$slug] = true;
            $items[] = [
                'label' => $f,
                'q' => $slug,
            ];
        }
    }

    return $items;
}


function estimate_read_time_minutes(string $text): int
{
    $text = trim($text);
    if ($text === '') {
        return 1;
    }
    $words = preg_split('/\s+/u', $text) ?: [];
    $count = 0;
    foreach ($words as $w) {
        $w = trim((string) $w);
        if ($w !== '') {
            $count++;
        }
    }
    $minutes = (int) ceil($count / 200);
    return max(1, $minutes);
}

function iso8601_now_with_offset(): string
{
    try {
        $dt = new DateTime('now');
        return $dt->format('c');
    } catch (Throwable $e) {
        return gmdate('c');
    }
}

function select_unique_snippets(array $candidates, array $excludeLower, int $count): array
{
    $out = [];
    $seen = [];
    foreach ($excludeLower as $x) {
        $k = strtolower(trim((string) $x));
        if ($k !== '') {
            $seen[$k] = true;
        }
    }

    foreach ($candidates as $c) {
        if (count($out) >= $count) {
            break;
        }
        $c = trim((string) $c);
        if ($c === '') {
            continue;
        }
        $k = strtolower($c);
        if (isset($seen[$k])) {
            continue;
        }
        $seen[$k] = true;
        $out[] = $c;
    }

    while (count($out) < $count) {
        $fallback = trim((string) random_sentence());
        if ($fallback === '') {
            break;
        }
        $k = strtolower($fallback);
        if (isset($seen[$k])) {
            continue;
        }
        $seen[$k] = true;
        $out[] = $fallback;
    }

    return $out;
}

function split_sentences(string $text, int $max = 80): array
{
    $text = trim($text);
    if ($text === '') {
        return [];
    }
    $parts = preg_split('/(?<=[\.!\?])\s+/u', $text) ?: [];
    $out = [];
    foreach ($parts as $p) {
        $p = trim((string) $p);
        if ($p === '') {
            continue;
        }
        $out[] = $p;
        if (count($out) >= $max) {
            break;
        }
    }
    if (count($out) === 0) {
        return [$text];
    }
    return $out;
}

function sentences_to_paragraphs(array $sentences, int $perParagraph = 3): array
{
    $perParagraph = max(1, $perParagraph);
    $out = [];
    $buf = [];
    foreach ($sentences as $s) {
        $s = trim((string) $s);
        if ($s === '') {
            continue;
        }
        $buf[] = $s;
        if (count($buf) >= $perParagraph) {
            $out[] = implode(' ', $buf);
            $buf = [];
        }
    }
    if (count($buf) > 0) {
        $out[] = implode(' ', $buf);
    }
    return $out;
}

$rawKeyword = normalize_keyword($_GET['q'] ?? null);
if ($rawKeyword === '') {
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
    $pathOnly = (string) (strtok($uri, '?') ?: '');
    if (preg_match('#^/(super-updates|a)/([^/?#]+)$#i', $pathOnly, $m)) {
        $rawKeyword = normalize_keyword(urldecode((string) $m[2]));
    }
}

if ($rawKeyword === '') {
    http_response_code(400);
    header('Content-Type: text/html; charset=UTF-8');
    echo "<!doctype html>\n";
    echo "<html lang=\"en\">\n";
    echo "<head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>AGC</title></head>\n";
    echo "<body style=\"font-family:system-ui\"><main style=\"max-width:720px;margin:40px auto\">\n";
    echo "<h1>Enter keyword</h1><form method=\"get\"><input name=\"q\" required> <button>Go</button></form>";
    echo "</main></body></html>";
    exit;
}

$slug = slugify($rawKeyword);
$keyword = $rawKeyword;
if (strpos($keyword, '-') !== false && strpos($keyword, ' ') === false) {
    $keyword = str_replace('-', ' ', $keyword);
}
// SETUP CACHE SYSTEM
$cacheSlug = slugify($rawKeyword);
$cacheFile = data_cache_file($cacheSlug !== '' ? $cacheSlug : $rawKeyword);
$cacheTtl = data_cache_ttl();
$bypassCache = isset($_GET['refresh']) && (string) $_GET['refresh'] === '1';

$pageData = null;

if (!$bypassCache && data_cache_enabled()) {
    $pageData = data_cache_read($cacheFile, $cacheTtl);
}

// IF NOT IN CACHE, FETCH EXTERNAL DATA (BING & SUGGESTIONS)
if ($pageData === null) {
    $bing = bing_image_search($keyword, 3);
    $published = iso8601_now_with_offset();

    // Fetch Google Suggestions to grow sitemap
    $proxyUrl = env_get('PROXY_URL', '');
    $suggestions = fetch_google_suggestions($keyword, $proxyUrl !== '' ? $proxyUrl : null);
    if (count($suggestions) > 0) {
        append_new_keywords($suggestions);
    }

    // Package only the crucial data for cache
    $pageData = [
        'bing' => $bing,
        'published' => $published,
    ];

    if (data_cache_enabled() && ($bing['ok'] ?? false)) {
        data_cache_write($cacheFile, $pageData);
    }
}

// EXTRACT CACHED DATA
$bing = $pageData['bing'];
$published = $pageData['published'];

// GENERATE DETERMINISTIC TEXT BASED ON FULL URL
$currentScheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$currentHost = $_SERVER['HTTP_HOST'] ?? 'localhost';
$currentUri = $_SERVER['REQUEST_URI'] ?? '/';
$fullCurrentUrl = $currentScheme . '://' . $currentHost . $currentUri;

// We seed the RNG so array_rand() and shuffle() return the exact same results for this specific URL
mt_srand(crc32($fullCurrentUrl));

$h1 = $keyword . ' ' . random_sentence();

$randomText = build_random_text($keyword, 200);
$randomText2 = build_random_text($keyword, 200);
$randomText3 = build_random_text($keyword, 200);

$randomTextSentences = split_sentences($randomText, 140);
$randomTextSentencesH2 = split_sentences($randomText2, 30);
$randomTextSentencesH3 = split_sentences($randomText3, 30);
$randomTextParagraphs = sentences_to_paragraphs($randomTextSentences, 3);
$randomTextParagraphsH2 = sentences_to_paragraphs($randomTextSentencesH2, 3);
$randomTextParagraphsH3 = sentences_to_paragraphs($randomTextSentencesH3, 3);

$h2aTitle = random_phrase() . ' ' . $keyword;
$h2bTitle = random_phrase() . ' ' . $keyword;

$candidateSnippets = $randomTextSentences;
$candidateSnippets[] = $keyword . ' ' . random_sentence();
$candidateSnippets[] = random_phrase() . ' ' . $keyword;

$usedLower = array_map('strtolower', $randomTextSentences);
$h1Snips = select_unique_snippets($candidateSnippets, $usedLower, 2);
$usedLower = array_merge($usedLower, array_map('strtolower', $h1Snips));
$h2aSnips = select_unique_snippets($candidateSnippets, $usedLower, 2);
$usedLower = array_merge($usedLower, array_map('strtolower', $h2aSnips));
$h2bSnips = select_unique_snippets($candidateSnippets, $usedLower, 2);
$usedLower = array_merge($usedLower, array_map('strtolower', $h2bSnips));
$h3Snips = select_unique_snippets($candidateSnippets, $usedLower, 2);

// Completely randomize the related links by resetting the seed
mt_srand();
$relatedLinks = build_related_links($keyword, 6);

// Restore seed to maintain consistency for the rest of the generation process
mt_srand(crc32($fullCurrentUrl));

$metaText = $h1 . ' ' . $randomText . ' ' . implode(' ', $h1Snips) . ' ' . $h2aTitle . ' ' . implode(' ', $h2aSnips) . ' ' . $h2bTitle . ' ' . implode(' ', $h2bSnips) . ' ' . implode(' ', $h3Snips);
$readMinutes = estimate_read_time_minutes($metaText);

// Reset RNG so it doesn't stay seeded for other underlying scripts
mt_srand();

// LOAD AUTHORS
$authorsJson = __DIR__ . '/authors.json';
$authorsPool = [];
if (is_file($authorsJson)) {
    $raw = file_get_contents($authorsJson);
    $authorsPool = json_decode($raw, true) ?: [];
}

// Select deterministically based on seed
if (count($authorsPool) > 0) {
    mt_srand(crc32((string) $fullCurrentUrl));
    $selectedAuthor = $authorsPool[array_rand($authorsPool)];
    mt_srand(); // reset
} else {
    $selectedAuthor = ['name' => db_get_config('site_name', $host), 'role' => 'Editor', 'slug' => ''];
}


// VARIABLES ALWAYS DETERMINED PER PAGE LOAD
$pageTitle = $h1;
$metaDescription = 'Summary and related information for ' . $keyword . '.';
$ogImage = '';
if (isset($bing['images']) && is_array($bing['images']) && isset($bing['images'][0])) {
    $ogImage = trim((string) $bing['images'][0]);
}

$scheme = seo_detect_scheme();
$host = seo_detect_host();
$siteName = db_get_config('site_name', $host);
$currentSlug = db_get_host_slug();
$canonicalSlug = $slug !== '' ? $slug : slugify($keyword);
$canonical = $scheme . '://' . $host . '/' . $currentSlug . '/' . rawurlencode($canonicalSlug !== '' ? $canonicalSlug : $keyword);

$ratingValue = null;
$ratingCount = null;
if (isset($_GET['rating'])) {
    $rv = (string) $_GET['rating'];
    if (is_numeric($rv)) {
        $ratingValue = (float) $rv;
    }
}
if (isset($_GET['ratingCount'])) {
    $rc = (string) $_GET['ratingCount'];
    if (is_numeric($rc)) {
        $ratingCount = (int) $rc;
    }
}

header('Content-Type: text/html; charset=UTF-8');

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= e($pageTitle) ?></title>
    <link rel="icon" href="/favicon.svg" type="image/svg+xml">
    <link rel="shortcut icon" href="/favicon.svg">
    <meta name="description" content="<?= e($metaDescription) ?>">
    <link rel="canonical" href="<?= e($canonical) ?>">
    <meta name="robots" content="index,follow">
    <meta property="og:type" content="article">
    <meta property="og:site_name" content="<?= e($host) ?>">
    <meta property="og:title" content="<?= e($pageTitle) ?>">
    <meta property="og:description" content="<?= e($metaDescription) ?>">
    <meta property="og:url" content="<?= e($canonical) ?>">
    <?php if ($ogImage !== ''): ?>
        <meta property="og:image" content="<?= e($ogImage) ?>">
    <?php endif; ?>
    <meta name="twitter:card" content="<?= e($ogImage !== '' ? 'summary_large_image' : 'summary') ?>">
    <meta name="twitter:title" content="<?= e($pageTitle) ?>">
    <meta name="twitter:description" content="<?= e($metaDescription) ?>">
    <?php if ($ogImage !== ''): ?>
        <meta name="twitter:image" content="<?= e($ogImage) ?>">
    <?php endif; ?>
    <script type="application/ld+json"><?= seo_schema_news_breadcrumb_jsonld([
        'baseUrl' => $scheme . '://' . $host,
        'canonical' => $canonical,
        'host' => $host,
        'siteName' => $siteName,
        'headline' => $pageTitle,
        'description' => $metaDescription,
        'datePublished' => $published,
        'dateModified' => $published,
        'images' => (array) (($bing['images'] ?? []) ?: []),
        'authorName' => $selectedAuthor['name'],
        'authorJobTitle' => $selectedAuthor['role'],
        'breadcrumbSectionName' => 'News',
        'breadcrumbSectionUrl' => $canonical,
        'ratingValue' => $ratingValue,
        'ratingCount' => $ratingCount,
    ]) ?></script>
    <style>
        :root {
            --bg: #0f1115;
            --text: #f2f4f7;
            --muted: #a7b0bb;
            --border: rgba(255, 255, 255, .08);
            --accent: #ff3b3b
        }

        body {
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
            line-height: 1.75;
            margin: 0;
            background: var(--bg);
            color: var(--text);
            font-size: 17px
        }

        .container {
            max-width: 980px;
            margin: 0 auto;
            padding: 26px 22px
        }

        .top {
            display: flex;
            gap: 14px;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--border);
            padding-bottom: 14px;
            margin-bottom: 20px
        }

        .brand {
            font-weight: 900;
            letter-spacing: .08em;
            text-decoration: none;
            color: var(--text)
        }

        .nav {
            display: flex;
            gap: 14px;
            flex-wrap: wrap
        }

        .nav a {
            text-decoration: none;
            color: var(--muted);
            font-size: 0.9rem
        }

        .nav a:hover {
            color: var(--text)
        }

        main {
            max-width: 920px;
            margin: 0 auto
        }

        a {
            color: var(--accent);
            text-decoration: none
        }

        a:hover {
            text-decoration: underline
        }

        .meta {
            color: var(--muted);
            font-size: .95rem;
            margin: 6px 0 18px
        }

        .muted {
            color: var(--muted)
        }

        p {
            margin: 0 0 14px;
            overflow-wrap: anywhere
        }

        .card {
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 16px;
            margin: 16px 0;
            background: rgba(255, 255, 255, .03)
        }

        .error {
            border-color: rgba(255, 79, 79, .45);
            background: rgba(255, 79, 79, .06)
        }

        .imggrid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px;
            margin-top: 10px
        }

        img {
            width: 100%;
            height: auto;
            border-radius: 12px;
            border: 1px solid var(--border);
            background: #0b0d10
        }

        h1,
        h2,
        h3 {
            line-height: 1.18;
            color: #ffffff
        }

        h1 {
            margin: 0 0 10px;
            font-size: 2.2rem;
            letter-spacing: -.01em
        }

        h2 {
            margin: 26px 0 10px;
            font-size: 1.5rem
        }

        h3 {
            margin: 20px 0 8px;
            font-size: 1.12rem
        }

        ul {
            margin: 10px 0 0 18px
        }

        li {
            margin: 6px 0
        }

        .footer {
            border-top: 1px solid var(--border);
            margin-top: 40px;
            padding-top: 20px;
            color: var(--muted);
            font-size: .95rem;
            text-align: center
        }

        @media (max-width:720px) {
            .imggrid {
                grid-template-columns: repeat(2, minmax(0, 1fr))
            }

            h1 {
                font-size: 1.85rem
            }

            .top {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <header class="top">
            <a class="brand" href="/"><?= e($siteName) ?></a>
            <nav class="nav" aria-label="Secondary">
                <a href="/dmca">DMCA</a>
                <a href="/contact">Contact</a>
                <a href="/privacy-policy">Privacy Policy</a>
                <a href="/copyright">Copyright</a>
                <a href="/authors">Authors</a>
            </nav>
        </header>

        <main>
            <article>
                <h1><?= e($h1) ?></h1>
                <div class="meta"><?= e($published) ?> • <?= e((string) $readMinutes) ?> minute read • By <a
                        href="/authors/<?= e($selectedAuthor['slug']) ?>"><?= e($selectedAuthor['name']) ?></a></div>
                <div style="text-align: center; margin: 20px 0;">
                    <?php include 'banner.html'; ?>
                </div>

                <?php foreach ($randomTextParagraphs as $para): ?>
                    <p><?= e((string) $para) ?></p>
                <?php endforeach; ?>
                <?php foreach ($h1Snips as $sn): ?>
                <?php endforeach; ?>

                <h2><?= e($h2aTitle) ?></h2>
                <?php foreach ($randomTextParagraphsH2 as $para): ?>
                    <p><?= e((string) $para) ?></p>
                <?php endforeach; ?>
                <?php foreach ($h2aSnips as $sn): ?>
                <?php endforeach; ?>

                <div style="text-align: center; margin: 20px 0;">
                    <?php include 'native.html'; ?>
                </div>
                <div style="text-align: center; margin: 20px 0;">
                    <?php include 'visitor.html'; ?>
                </div>

                <?php if (count($relatedLinks) > 0): ?>
                    <ul>
                        <?php foreach ($relatedLinks as $item): ?>
                            <li><a
                                    href="/<?= e($currentSlug) ?>/<?= e(rawurlencode((string) $item['q'])) ?>"><?= e((string) $item['label']) ?></a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

                <h2><?= e($h2bTitle) ?></h2>
                <?php foreach ($randomTextParagraphsH3 as $para): ?>
                    <p><?= e((string) $para) ?></p>
                <?php endforeach; ?>
                <?php foreach ($h2bSnips as $sn): ?>
                <?php endforeach; ?>

                <h3>Gallery Photos</h3>
                <section class="card" aria-label="Images">
                    <?php if (($bing['ok'] ?? false) && count((array) ($bing['images'] ?? [])) > 0): ?>
                        <div class="imggrid">
                            <?php foreach ((array) $bing['images'] as $imgUrl): ?>
                                <figure>
                                    <img src="<?= e((string) $imgUrl) ?>" alt="<?= e($keyword) ?>" loading="lazy"
                                        decoding="async" referrerpolicy="no-referrer">
                                </figure>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="muted">Image fetch failed. <?= e((string) ($bing['error'] ?? '')) ?></p>
                    <?php endif; ?>
                </section>

            </article>
        </main>

        <footer class="footer">
            © <?= e((string) date('Y')) ?> <?= e($siteName) ?> • <a href="/sitemap.xml">Sitemap</a>
        </footer>
    </div>
</body>

</html>